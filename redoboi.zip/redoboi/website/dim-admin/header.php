<?php
	session_start();
	
	/* TO HIDE WARNING MESSAGE */
	ini_set('display_errors', 1);
	ini_set('error_reporting', E_ERROR);	
		
	include ("include/connection.php");
	include ("include/config.php");
	include ("include/function.php");
	
	/* SET THE DEFAULT TIME TO JAKARTA */
	date_default_timezone_set("Asia/Jakarta");
	
	/* CHECK WHETHER THE USER HAS BEEN LOGGED IN */
	df_check_user_session();
	
	/* GET ACT, SUBACT, AND SUBSUBACT TO DETERMINE THE CONTENT THAT WILL BE LOADED */
	$act = ''; $sub_act = ''; $sub_sub_act = '';
	if(isset($_GET['a'])) $act = $_GET['a'];
	if(isset($_GET['s_a'])) $sub_act = $_GET['s_a'];
	if(isset($_GET['s_s_a'])) $sub_sub_act = $_GET['s_s_a'];
	
	/* SET THE DEFAULT ACT BASED ON USER'S PRIVILEGE */
	if($act == '')
	{
		if(df_have_privilege('all')) { $act = 'webconfig'; }
		else if(df_have_privilege('conf')) { $act = 'webconfig'; }
		else if(df_have_privilege('user')) { $act = 'user'; $sub_act = 'privilege'; } 
		else if(df_have_privilege('dom')) { $act = 'domain'; $sub_act = 'hosting';}
		else { $act = ''; $sub_act = ''; $sub_sub_act = ''; } 
	}
	
	/* GET SPECIFIED TASK OF THE LOADED CONTENT */
	$task = '';
	if(isset($_GET['t'])) $task = $_GET['t'];	
	
	/* FOR DETERMINE THE PAGING */
	if(isset($_GET['p'])) $pagenum = intval($_GET['p']);
	else $pagenum = 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title><?php echo ucwords(df_proc_output($company_name_config)); ?> - Administration Page</title>
<link rel="shortcut icon" href=	"<?php if($favicon_config != '') echo $images_preurl.'/favicon/'.$favicon_config; else echo $images_preurl.'/favicon/default.ico'; ?>"/>

<link href="<?php echo $admin_preurl; ?>/css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery-ui-1.9.2.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/maps.googleapis.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/jquery.sparkline.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.fullcalendar.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.select2.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.bootbox.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/tables/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/files/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.validation.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.validationEngine-en.js"></script>
<?php /* <script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/functions/forms.js"></script> */ ?>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/functions/index.js"></script>


</head>