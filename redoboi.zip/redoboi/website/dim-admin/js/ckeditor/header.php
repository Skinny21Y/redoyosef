<?php
	session_start();
	ini_set('display_errors', 1);
	ini_set('error_reporting', E_ERROR);
	
	include ("include/connection.php");
	include ("include/config.php");
	include ("include/function.php");
	include ("include/query-function.php");
	
	check_user_session();
	
	$act = $_GET['a'];
	$sub_act = $_GET['s_a'];
	$sub_sub_act = $_GET['s_s_a'];
	
	if($act == '')
	{
		if(have_privilege('all')) $act = 'webconfig';
		else if(have_privilege('conf')) $act = 'webconfig';
		/* else if(have_privilege('acc')) { $act = 'account'; $sub_act = 'user'; } */
		else if(have_privilege('pag')) { $act = 'pages'; $sub_act = 'home'; }
		else if(have_privilege('ban')) { $act = 'banner'; }
		else if(have_privilege('new')) { $act = 'news'; }
		else if(have_privilege('med')) { $act = 'media'; }
		else if(have_privilege('pro')) { $act = 'product'; $sub_act = 'category'; }
		else if(have_privilege('app')) { $act = 'application'; }
		/* else if(have_privilege('car')) { $act = 'career'; } */
		else if(have_privilege('faq')) { $act = 'faq'; }
	}
	
	$task = $_GET['t'];
	
	if(isset($_GET['p'])) $pagenum = intval($_GET['p']);
	else $pagenum = 1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
<title>Administration Page - <? echo ucwords($company_name_config); ?></title>
<link rel="shortcut icon" href=	"<?php if($favicon_config != '') echo $images_preurl.'/favicon/'.$favicon_config; else echo $images_preurl.'/favicon/default.ico'; ?>"/>
<link href="<?php echo $admin_preurl; ?>/css/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/spinner/ui.spinner.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/spinner/jquery.mousewheel.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery-ui.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/jquery.sparkline.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/uniform.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.cleditor.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.validationEngine-en.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.validationEngine.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/autogrowtextarea.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.maskedinput.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.dualListBox.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/jquery.inputlimiter.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/forms/chosen.jquery.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/wizard/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/wizard/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/wizard/jquery.form.wizard.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/uploader/plupload.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/uploader/plupload.html5.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/uploader/plupload.html4.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/uploader/jquery.plupload.queue.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/tables/datatable.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/tables/tablesort.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/tables/resizable.min.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.tipsy.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.progress.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.timeentry.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.jgrowl.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.breadcrumbs.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/ui/jquery.sourcerer.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/calendar.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/elfinder.min.js"></script>

<!---- CUSTOMED ----->
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/customed/custom.js"></script>

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/customed/fancybox/jquery.fancybox-1.3.1.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $admin_preurl; ?>/js/customed/fancybox/jquery.fancybox-1.3.1.css" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$(".popup-fancy a").fancybox({
			  'titleShow'	: false,
			  'padding'		: 0,
			  'scrolling'	: 'no',
			  'hideOnOverlayClick': false,
			  'autoScale'	: false
			  });
		
		 $("a.popup-fancy").fancybox({
			  'titleShow'	: false,
			  'padding'		: 0,
			  'scrolling'	: 'no',
			  'hideOnOverlayClick': false,
			  'autoScale'	: false
			  });
			  
		 $("a.popup-fancy-edit").fancybox({
			  'titleShow'	: false,
			  'padding'		: 0,
			  'scrolling'	: 'yes',
			  'hideOnOverlayClick': false,
			  'autoScale'	: false
			  });			  
	});
</script>

<!------------------->

</head>