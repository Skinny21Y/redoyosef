<?php
	//$res_config = mysql_query("SELECT * FROM web_config");

	$res_config = mysqli_query($connectsql, "SELECT * FROM web_config");

	if( mysqli_num_rows($res_config) > 0)
	{
		$row_config = mysqli_fetch_array($res_config);
		
		/* ALL OF THE WEBSITE CONFIG VARIABLE ENDS WITH '_config' */
		$company_name_config = $row_config['company_name'];
		$tag_line_config = $row_config['tag_line'];
		
		$address_config = $row_config['address'];
		$building_config = $row_config['building'];
		$city_config = $row_config['city'];
		$country_config = $row_config['country'];
		
		$phone1_config = $row_config['phone1'];
		$phone2_config = $row_config['phone2'];		
		$email1_config = $row_config['email1'];
		$email2_config = $row_config['email2'];
		
		$twitter_config = $row_config['twitter_link'];
		$facebook_config = $row_config['facebook_link'];
		$youtube_config = $row_config['youtube_link'];
		$blog_config = $row_config['blog_link'];
		$linkedin_config = $row_config['linkedin_link'];
		$pinterest_config = $row_config['pinterest_link'];
		$instagram_config = $row_config['instagram_link'];
		
		$website_name_config = $row_config['website_name'];
		$website_url_config = $row_config['website_url'];
		$meta_copyright_config = $row_config['meta_copyright'];
		$meta_keywords_config = $row_config['meta_keywords'];
		$meta_description_config = $row_config['meta_description'];
		
		$logo_config = $row_config['logo'];
		$logo_alt_config = $row_config['logo_alt'];
		$favicon_config = $row_config['favicon'];
		
		$dc_key_config = $row_config['dc_key'];
		
		$dc_user_id = $dc_key_config.'_user_id';
		$dc_user_name = $dc_key_config.'_user_name';
		$dc_user_privilege = $dc_key_config.'_user_privilege';
		
		$notif_type_key = 'notif_type_back_'.$dc_key_config;
		$notif_word_key = 'notif_word_back_'.$dc_key_config;
		
		$page_session_key = 'page_admin_'.$dc_key_config;
	}
	
	/* ---- USABLE URL (ENDS IN '_preurl', AND ONLY COVER THE FRONT END) ----- */	
	$admin_folder_name = 'dim-admin';
	
	$root_preurl = '/website';
	
	$admin_preurl = $root_preurl.'/'.$admin_folder_name;
	$images_preurl = $root_preurl.'/images';
	$scripts_preurl = $root_preurl.'/scripts';
	$css_preurl = $root_preurl.'/css';
	$sql_preurl = $root_preurl.'/sql'; 
	/* ----------------------------------------------------------------------- */
?>