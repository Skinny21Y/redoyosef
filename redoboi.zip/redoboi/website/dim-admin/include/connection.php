

<?php
	$dbname = "redoboi";
	
	$dbhost = "localhost";
	$dbusername = "root";
	$dbpassword = "";

$connectsql = new mysqli($dbhost, $dbusername, $dbpassword, $dbname);

if ($connectsql->connect_error) {
    die('Connect Error (' . $connectsql->connect_errno . ') '
            . $connectsql->connect_error);
}


if (mysqli_connect_error()) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}


?>