<!-- Sidebar -->
<div id="sidebar">
	<div id="general">
		<!-- Sidebar user -->
		<div class="sidebar-user widget">
			<div class = "main-logo">
				<a href = "panel.php"><img src = "<?php echo $images_preurl; ?>/logo/<?php echo $logo_config; ?>" alt = "<?php echo $logo_alt_config; ?>"></a>
			</div>
		</div>
		<!-- /sidebar user -->

		<!-- Main navigation -->
		<ul class="navigation widget">
			
			<?php
				if(df_have_privilege('all') || df_have_privilege('conf'))
				{
				?>
					<li>
						<a href="#" title="" class="expand <?php if($act == '' || $act == 'webconfig') echo 'subOpened'; ?>" <?php if($act == '' || $act == 'webconfig') echo 'id = "current"'; ?>><i class="icon-cog"></i>Website Configuration<strong>3</strong></a>
						<ul>
							<li><a href="panel.php?a=webconfig&s_a=setting" title="" <?php if(($act == '' || $act == 'webconfig') && ($sub_act == '' || $sub_act == 'setting')) echo 'class = "current"'; ?>>General Settings</a></li>
							<li><a href="panel.php?a=webconfig&s_a=logo" title="" <?php if(($act == '' || $act == 'webconfig') && $sub_act == 'logo') echo 'class = "current"'; ?>>Website Main Logo</a></li>
							<li><a href="panel.php?a=webconfig&s_a=favicon" title="" <?php if(($act == '' || $act == 'webconfig') && $sub_act == 'favicon') echo 'class = "current"'; ?>>Website Icon</a></li>
						</ul>
					</li>
				<?php
				}
			?>
			
			<?php
				if(df_have_privilege('all') || df_have_privilege('user'))
				{
				?>
					<li>
						<a href="#" title="" class="expand <?php if($act == 'user') echo 'subOpened'; ?>" <?php if($act == 'user') echo 'id = "current"'; ?>><i class="icon-user"></i>User Management<strong>2</strong></a>
						<ul>
							<li><a href="panel.php?a=user&s_a=privilege" title="" <?php if($act == 'user' && $sub_act == 'privilege') echo 'class = "current"'; ?>>Privilege</a></li>
							<li><a href="panel.php?a=user&s_a=user" title="" <?php if($act == 'user' && $sub_act == 'user') echo 'class = "current"'; ?>>Users</a></li>
						</ul>
					</li>
				<?php
				}
			?>
			

			
			<?php
				if(df_have_privilege('all') || df_have_privilege('dom'))
				{
				?>
					<li>
						<a href="#" title="" class="expand <?php if($act == 'domain') echo 'subOpened'; ?>" <?php if($act == 'domain') echo 'id = "current"'; ?>><i class="icon-globe"></i>Clients Domain<strong>2</strong></a>
						<ul>
							<li><a href="panel.php?a=domain&s_a=hosting" title="" <?php if($act == 'domain' && $sub_act == 'hosting') echo 'class = "current"'; ?>>Hosting Provider</a></li>
							<li><a href="panel.php?a=domain&s_a=domain" title="" <?php if($act == 'domain' && $sub_act == 'domain') echo 'class = "current"'; ?>>Domain</a></li>
						</ul>
					</li>
				<?php
				}
			?>


			<?php
				if(df_have_privilege('all') || df_have_privilege('dom'))
				{
				?>
					<li <?php if($act == 'lala') echo 'class = "current"'; ?>>
						<a href="panel.php?a=lala" title=""><i class="icon-user-md"></i>Account List</a>
					</li>
				<?php
				}
			?>
		</ul>
		<!-- /main navigation -->

	</div>
</div>
<!-- /sidebar -->