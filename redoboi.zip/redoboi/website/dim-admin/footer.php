	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <?php echo date('Y'); ?> <?php echo ucwords(df_proc_output($website_name_config)); ?></div>
		<ul class="footer-links">
			<li><a href="http://dimbleweb.com" target = "_blank" title="Visit Dimbleweb" class = "powered"><i class = "icon-certificate"></i>Powered by Dimbleweb</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>
</html>