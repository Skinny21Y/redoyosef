<?php
	/* --- ADMIN USER --- */
	if($act == 'user-profile' && $task == 'edit') include ("lib/profile/edit-profile.php"); 
	else if($act == 'user-password' && $task == 'edit') include ("lib/profile/edit-password.php"); 
	else if($act == 'user-picture' && $task == 'edit') include ("lib/profile/edit-picture.php");	
	/* ------------------ */
	
	/* --- WEBSITE CONFIGURATION --- */	
	else if($act == 'webconfig') 
	{		
		if($sub_act == '' || $sub_act == 'setting')
		{
			include ("lib/webconfig/edit-setting.php"); 		
		}
		else if($sub_act == 'logo') 
		{
			include ("lib/webconfig/edit-logo.php"); 	
		}
		else if($sub_act == 'favicon') 
		{
			include ("lib/webconfig/edit-favicon.php"); 	
		}
	}
	/* ----------------------------- */
	
	/* --- USER MANAGEMENT --- */	
	else if($act == 'user')
	{
		if($sub_act == 'privilege')
		{
			if($task == '') include ("lib/user/list-privilege.php"); 
			else if($task == 'add') include ("lib/user/add-privilege.php"); 
			else if($task == 'edit') include ("lib/user/edit-privilege.php"); 			
		}
		else if($sub_act == 'user')
		{
			if($task == '') include ("lib/user/list-user.php"); 
			else if($task == 'add') include ("lib/user/add-user.php"); 
			else if($task == 'edit') include ("lib/user/edit-user.php"); 			
		}
	}
	/* ----------------------- */
	
	/* --- DOMAIN --- */
	else if($act == 'domain')
	{
		if($sub_act == 'hosting')
		{
			if($task == '') include ("lib/domain/list-hosting.php"); 
			else if($task == 'add') include ("lib/domain/add-hosting.php"); 
			else if($task == 'edit') include ("lib/domain/edit-hosting.php"); 			
		}
		else if($sub_act == 'domain')
		{
			if($sub_sub_act == '')
			{
				if($task == '') include ("lib/domain/list-domain.php"); 
				else if($task == 'add') include ("lib/domain/add-domain.php"); 
				else if($task == 'edit') include ("lib/domain/edit-domain.php"); 	
			}
			if($sub_sub_act == 'document')
			{
				if($task == '') include ("lib/domain/list-document.php"); 
				else if($task == 'add') include ("lib/domain/add-document.php"); 
				else if($task == 'edit') include ("lib/domain/edit-document.php"); 	
			}
		}
	}
	/* ------------- */

	/* --- ACCOUNT LIST --- */
	else if($act == 'lala')
	{
		
		if($task == '') include ("lib/accountlist/accountlist.php"); 
		else if($task == 'add') include ("lib/accountlist/add-account.php"); 
		else if($task == 'edit') include ("lib/accountlist/edit-account.php"); 			
		
	}
	/* ------------- */
?>