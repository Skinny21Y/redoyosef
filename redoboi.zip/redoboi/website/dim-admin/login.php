<?php	
	session_start();
	
	/* TO HIDE WARNING MESSAGE */
	ini_set('display_errors', 1);
	ini_set('error_reporting', E_ERROR);	
	
	/* SET THE DATE */
	date_default_timezone_set("Asia/Jakarta");
	
	include ("include/connection.php");
	include ("include/config.php");
	include ("include/function.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title><?php echo ucwords(df_proc_output($company_name_config)); ?> - Administration Page</title>
<link rel="shortcut icon" href=	"<?php if($favicon_config != '') echo $images_preurl.'/favicon/'.$favicon_config; else echo $images_preurl.'/favicon/default.ico'; ?>"/>

<link href="<?php echo $admin_preurl; ?>/css/fonts.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $admin_preurl; ?>/css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/general/jquery-ui-1.9.2.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/plugins/charts/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/files/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo $admin_preurl; ?>/js/functions/error.js"></script>

<script type = "text/javascript">
$(document).ready(function(){
	$('#forgot-pass-btn').click(function(){
		$('#dcust-login-form').slideUp(300);
		$('#dcust-forgot-pass-form').slideDown(300);
	});
	
	$('#login-btn').click(function(){
		$('#dcust-forgot-pass-form').slideUp(300);
		$('#dcust-login-form').slideDown(300);
	});
});
</script>

</head>

<body class="no-background">
<?php
	if(isset($_GET['ty'])) $ty = intval($_GET['ty']);
	else $ty = 0;
?>

	<!-- Error wrapper -->
	<div class="error-page">
		<a href = "/<?php echo $admin_folder_name; ?>"><img src = "<?php echo $images_preurl; ?>/logo/<?php echo $logo_config; ?>"></a>
		<div class="error-content">
			<h2 class = "sans">ADMINISTRATION PAGE</h2>
	        <span class="reason-title">Please enter your username and password</span>

			<div id = "dcust-login-form" <?php if($ty != 0) echo 'style = "display: none;"'; ?>>
				<form class="search" action="<?php echo $admin_preurl; ?>/lib/other/do-login.php" method = "POST">
					<div>
						<input type="text" name = "username" id = "username" class = "username" placeholder="Username..." required/>
						<input type="password" name = "password" id = "password" class = "password no-mb" placeholder="Password..." required/>
					</div>

					<div class="row-fluid error-buttons">
						<input type = "submit" value = "LOGIN" class = "btn btn-success" name = "login_submit">
						&nbsp;&nbsp;<a class = "text" id = "forgot-pass-btn">Forgot Your Password?</a>
					</div>
				</form>
				<?php
					if(isset($_SESSION[$notif_type_key]) && isset($_SESSION[$notif_type_word]) && $_SESSION[$notif_type_key] == 'failed' && $ty == 0)
					{
						?>
							<div class = "dcust-err-msg"><?php echo ucfirst(df_proc_output($_SESSION[$notif_type_word])); ?></div>
						<?php
						if(isset($_SESSION[$notif_type_key])) unset($_SESSION[$notif_type_key]);
						if(isset($_SESSION[$notif_type_word])) unset($_SESSION[$notif_type_word]);
					}
				?>				
			</div>
			
			<div id = "dcust-forgot-pass-form" <?php if($ty == 0) echo 'style = "display: none;"'; else echo 'style = "display: block;"'; ?>>
				<form class="search" method = "POST" action = "<?php echo $admin_preurl; ?>/lib/other/do-forgot-password.php">
					<div>
						<input type="email" name = "email" id = "email" class = "email" placeholder="Enter Your Email Address..." required/>
					</div>

					<div class="row-fluid error-buttons">
						<input type = "submit" value = "RESET PASSWORD" class = "btn btn-success" name = "forgot_password_submit">
						&nbsp;&nbsp;<a class = "text" id = "login-btn">Sign In</a>
					</div>
				</form>
				<?php
					if($ty != 0)
					{
						if($ty == 1) { ?> <div class = "dcust-err-msg"><?php echo ucfirst(df_proc_output($_SESSION[$notif_type_word])); ?></div> <?php }
						else if($ty == 2) { ?> <div class = "dcust-suc-msg"><?php echo ucfirst(df_proc_output($_SESSION[$notif_type_word])); ?></div> <?php }
						
						if(isset($_SESSION[$notif_type_key])) unset($_SESSION[$notif_type_key]);
						if(isset($_SESSION[$notif_type_word])) unset($_SESSION[$notif_type_word]);
					}
				?>
			</div>
	    </div>
	</div>  
	<!-- /error wrapper -->


	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <?php echo date('Y'); ?> <?php echo ucwords(df_proc_output($website_name_config)); ?></div>
		<ul class="footer-links">
			<li><a href="http://dimbleweb.com" target = "_blank" title="Visit Dimbleweb" class = "powered"><i class = "icon-certificate"></i>Powered by Dimbleweb</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>
</html>
