<?php	
	$client_id = df_proc_input($_GET['client_id']);
	$client_name = df_single_query_id_based('client_domain', 'name', $client_id);
?>

<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=domain&s_a=domain">Client Domain List</a></li>
		<li><a href = "panel.php?a=domain&s_a=domain&s_s_a=document&client_id=<?php echo $client_id; ?>">Related Documents for <b>'<?php echo ucwords(df_proc_output($client_name)); ?>'</b> Domain</a></li>
		<li class = "active"><a>Add New Document</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Add New Document for '<?php echo ucwords(df_proc_output($client_name)); ?>' Domain</h5>
		<span>Here you can add a new document related to '<?php echo ucwords(df_proc_output($client_name)); ?>' domain</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/domain/do-add-document.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<input type = "hidden" name = "client_id" value = "<?php echo $client_id; ?>">
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>
				<div class="control-group">
					<label class="control-label">Document Name: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required, maxSize[100]] span12" name="name" id="name">
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">
						Document <span class = "text-error">*</span>
					</label>
					<div class="controls">
						<span class = "span6">
							<input type="file" class="validate[required, custom[pdfonly]]" name = "pdfdoc" id = "pdfdoc">
							<span class="help-block">Only .pdf allowed</span>
						</span>
					</div>
				</div>
												
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "add_document_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>