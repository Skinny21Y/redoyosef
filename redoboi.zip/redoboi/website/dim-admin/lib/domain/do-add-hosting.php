<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(!isset($_POST['add_hosting_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{
			$name = df_proc_input($_POST['name']); 
			$url = df_proc_input($_POST['url']); 
			
			$res_name = mysqli_query($connectsql, "SELECT id FROM hosting_provider WHERE name = '$name'");
			if(mysqli_num_rows($res_name) > 0)
			{
				df_make_notification('failed', "The hosting provider named '$name' has been already added");
				df_go_to_admin_page('panel.php?a=domain&s_a=hosting&t=add');
			}
			else
			{
				$q_add = "INSERT INTO hosting_provider(name, url) 
						  VALUES('$name', '$url')";
				mysqli_query($connectsql, $q_add);
				
				$affrow = mysqli_affected_rows();
				if($affrow == 1)
				{				
					df_make_notification('success', 'New hosting provider has been added successfully');
				}
				else df_make_notification('failed', 'Failed to add new hosting provider');
			}
		}
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
?>