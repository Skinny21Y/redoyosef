<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(!isset($_POST['edit_hosting_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{		
			$id = df_proc_input($_POST['id']);		
			$name = df_proc_input($_POST['name']); 
			$url = df_proc_input($_POST['url']); 
			
			$res_name = mysqli_query("SELECT id FROM hosting_provider WHERE name = '$name' AND id <> '$id'");
			if(mysqli_num_rows($res_name) > 0)
			{
				df_make_notification('failed', "The hosting provider named '$name' has been already added");
				df_go_to_admin_page('panel.php?a=domain&s_a=hosting&t=edit&id='.$id);
			}
			else
			{
				$q_update = "UPDATE hosting_provider SET name = '$name', url = '$url' WHERE id = '$id'";
				mysqli_query($q_update);
				
				$affrow = 0;
				$affrow = mysqli_affected_rows();
				if($affrow == 0 || $affrow == 1) df_make_notification('success', 'The selected hosting provider has been updated successfully');
			}
		}
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
?>