<?php	
	$client_id = df_proc_input($_GET['client_id']);
	$client_name = df_single_query_id_based('client_domain', 'name', $client_id);
?>

<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=domain&s_a=domain">Client Domain List</a></li>
		<li class = "active"><a>Related Documents for <b>'<?php echo ucwords(df_proc_output($client_name)); ?>'</b> Domain</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Related Documents for <b>'<?php echo ucwords(df_proc_output($client_name)); ?>'</b> Domain</h5>
		<span>Here you can see the list of documents related to '<?php echo ucwords(df_proc_output($client_name)); ?>' domain</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	$item_num = 10;
	$path = 'panel.php?a=domain&s_a=domain&s_s_a=document&client_id='.$client_id;	
	$q_main_display = "SELECT * FROM domain_document WHERE client_id = '$client_id' ORDER BY id DESC";
	
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysqli_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>

<!-- BULKACTION FUNCTION -->
<script type = "text/javascript">
function bulkaction_check()
{
	var is_check = document.getElementById("masterCheck").checked;
	var bulked = document.forms['bulkaction-form']['document_list[]'];
	
	if(is_check)
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = true;
	}
	else
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = false;		
	}
}
</script>
<!------------------------->

<!-- Table with footer -->
<form action = "lib/domain/do-bulkaction-document.php" id = "bulkaction-form" name = "bulkaction-form" method = "post" enctype = "multipart/form-data" onsubmit = "return confirm('Are you sure?')">
<input type = "hidden" name = "client_id" value = "<?php echo $client_id; ?>">
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>Documents List</h6>
			<div class="nav pull-right">
				<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
				<ul class="dropdown-menu pull-right">
					<li><a href="panel.php?a=domain&s_a=domain&s_s_a=document&client_id=<?php echo $client_id; ?>&t=add"><i class="icon-plus"></i>Add New Document</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped table-checks">
			<thead>
				<tr>
					<th style = "width: 2%;"><input type="checkbox" name="checkRow" id = "masterCheck" onclick = "bulkaction_check()"/></th>
					<th style = "width: 5%;">No</th>
					<th style = "width: 30%;">Document Name</th>
					<th style = "width: 30%;">Document File</th>
					<th style = "width: 20%;">Last Update</th>
					<th style = "width: 12%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysqli_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysqli_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><input type="checkbox" name="document_list[]" value = "<?php echo df_proc_output($row['id']); ?>"/></td>
									<td><?php echo $no; ?></td>
									<td><?php echo ucwords(df_proc_output($row['name'])); ?></td>
									<td>
										<i class = "fam-zoom"></i><a href = "lib/domain/do-act-document.php?a=view&id=<?php echo $row['id']; ?>" title = "View Document" class = "tip" target = "_blank">&nbsp;View</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<i class = "fam-page-save"></i><a href = "lib/domain/do-act-document.php?a=download&id=<?php echo $row['id']; ?>" title = "View Document" class = "tip" >&nbsp;Download</a>										
									</td>
									<td><?php echo date('d/m/Y', strtotime($row['last_update'])); ?></td>
									<td>
										<ul class="table-controls">
											<li><a href="panel.php?a=domain&s_a=domain&s_s_a=document&client_id=<?php echo $client_id; ?>&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit Document"><i class="fam-pencil"></i></a> </li>
											<li><a href="lib/domain/do-delete-document.php?client_id=<?php echo $client_id; ?>&id=<?php echo $row['id']; ?>" class="tip" title="Delete Document" onclick = "return confirm('Are you sure you want to delete this document?')"><i class="fam-cross"></i></a></li>
										</ul>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "6" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysqli_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysqli_num_rows($result);
					$res_tot = mysqli_query($q_main_display);
					$tot_num = mysqli_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "6" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysqli_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<div class="table-actions">
						<label>Apply action:</label>
						<select class="styled">
							<option value="">Select action...</option>
							<option value="Delete">Delete Selected Documents</option>
						</select>
						&nbsp;&nbsp;<input type = "submit" class="btn btn-info" value = "Submit">
					</div>
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
</form>
<!-- /table with footer -->