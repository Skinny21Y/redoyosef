<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Hosting Provider List</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Hosting Provider List</h5>
		<span>Here you can see the list of domain hosting provider</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	$item_num = 10;
	$path = 'panel.php?a=domain&s_a=hosting';	
	$q_main_display = "SELECT * FROM hosting_provider ORDER BY id DESC";
	
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysqli_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>

<!-- BULKACTION FUNCTION -->
<script type = "text/javascript">
function bulkaction_check()
{
	var is_check = document.getElementById("masterCheck").checked;
	var bulked = document.forms['bulkaction-form']['hosting_list[]'];
	
	if(is_check)
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = true;
	}
	else
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = false;		
	}
}
</script>
<!------------------------->

<!-- Table with footer -->
<form action = "lib/domain/do-bulkaction-hosting.php" id = "bulkaction-form" name = "bulkaction-form" method = "post" enctype = "multipart/form-data" onsubmit = "return confirm('Are you sure?')">
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>Hosting Provider List</h6>
			<div class="nav pull-right">
				<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
				<ul class="dropdown-menu pull-right">
					<li><a href="panel.php?a=domain&s_a=hosting&t=add"><i class="icon-plus"></i>Add New Provider</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped table-checks">
			<thead>
				<tr>
					<th style = "width: 2%;"><input type="checkbox" name="checkRow" id = "masterCheck" onclick = "bulkaction_check()"/></th>
					<th style = "width: 5%;">No</th>
					<th style = "width: 18%;">Provider Name</th>
					<th style = "width: 30%;">Website URL</th>
					<th style = "width: 12%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysqli_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysqli_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><input type="checkbox" name="hosting_list[]" value = "<?php echo df_proc_output($row['id']); ?>"/></td>
									<td><?php echo $no; ?></td>
									<td><?php echo ucwords(df_proc_output($row['name'])); ?></td>
									<td><a href = "<?php echo df_proc_output($row['url']); ?>" target = "_blank" class = "tip" title = "Visit Website"><i><?php echo df_proc_output($row['url']); ?></i></a></td>
									<td>
										<ul class="table-controls">
											<li><a href="panel.php?a=domain&s_a=hosting&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit Provider"><i class="fam-pencil"></i></a> </li>
											<li><a href="lib/domain/do-delete-hosting.php?id=<?php echo $row['id']; ?>" class="tip" title="Delete Provider" onclick = "return confirm('Are you sure you want to delete this hosting provider?')"><i class="fam-cross"></i></a> </li>
										</ul>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "5" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysqli_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysqli_num_rows($result);
					$res_tot = mysqli_query($q_main_display);
					$tot_num = mysqli_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "5" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysqli_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<div class="table-actions">
						<label>Apply action:</label>
						<select class="styled">
							<option value="">Select action...</option>
							<option value="Delete">Delete Selected Providers</option>
						</select>
						&nbsp;&nbsp;<input type = "submit" class="btn btn-info" value = "Submit">
					</div>
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
</form>
<!-- /table with footer -->