<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=domain&s_a=domain">Client Domain List</a></li>
		<li class = "active"><a>Add New Domain</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Add New Domain</h5>
		<span>Here you can add a new domain data for one of your clients</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/domain/do-add-domain.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>
				<div class="control-group">
					<label class="control-label">Hosting Provider: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<select name = "hosting_provider_id" id = "hosting_provider_id" class = "styled validate[required]">
								<option value = "">--- Choose The Hosting Provider ---</option>
								<?php
									$res_provider = mysqli_query("SELECT * FROM hosting_provider ORDER BY id DESC");
									if(mysqli_num_rows($res_provider) > 0)
									{
										while($row_provider = mysqli_fetch_array($res_provider))
										{
											?>
												<option value = "<?php echo $row_provider['id']; ?>"><?php echo ucwords(df_proc_output($row_provider['name'])); ?></option>
											<?php
										}
									}
								?>
								<option value = "0">Unknown</option>
							</select>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Client Data: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="name" id="name">
							<span class = "help-block">Name <span class = "text-error">*</span></span>
						</span>
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="website_url" id="website_url">
							<span class = "help-block">Website URL <span class = "text-error">*</span></span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Contact Person: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="span12" name="person_name" id="person_name">
							<span class = "help-block">Name (optional)</span>
						</span>
						<span class = "span6">
							<input type="text" class="span12" name="person_phone" id="person_phone">
							<span class = "help-block">Phone (optional)</span>
						</span>
					</div>
				</div>				
				
				<div class="control-group">
					<label class="control-label">Cpanel Detail: </label>
					<div class="controls">
						<span class = "span4">
							<input type="text" class="validate[required] span12" name="cp_url" id="cp_url">
							<span class = "help-block">Cpanel URL <span class = "text-error">*</span></span>
						</span>
						<span class = "span4">
							<input type="text" class="validate[required] span12" name="cp_username" id="cp_username">
							<span class = "help-block">Cpanel Username <span class = "text-error">*</span></span>
						</span>
						<span class = "span4">
							<input type="text" class="validate[required] span12" name="cp_password" id="cp_password">
							<span class = "help-block">Cpanel Password <span class = "text-error">*</span></span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Domain Lifespan: </label>
					<div class="controls">
						<span class = "span3">
							<input type="text" class="datepicker" name = "domain_start_date" id = "domain_start_date"/>
							<span class = "help-block">Start Date (optional)</span>
						</span>
						<span class = "span3">
							<input type="text" class="datepicker" name = "domain_exp_date" id = "domain_exp_date"/>
							<span class = "help-block">Expired Date (optional)</span>
						</span>
					</div>
				</div>				
				
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "add_domain_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>