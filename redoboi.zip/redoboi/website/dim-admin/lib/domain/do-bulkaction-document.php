<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		$totalrow = 0;
		$client_id = $_POST['client_id'];
		
		for ($i = 0; $i < count($_POST['document_list']); $i++)
		{
			$id = $_POST['document_list'][$i];
			
			$res = mysqli_query("SELECT * FROM domain_document WHERE id = '$id'");
			if(mysqli_num_rows($res) == 1)
			{
				$row = mysqli_fetch_array($res);
				$doc_name = $row['file_name'];
				
				$q_delete = "DELETE FROM domain_document WHERE id = '$id'";
				mysqli_query($q_delete);
				if($doc_name != '') df_delete_document('document', 'domain', $doc_name);
				
				$affrow = mysqli_affected_rows();
				$totalrow = $totalrow + $affrow;
			}
		}  
		
		if($totalrow > 0) 
		{
			if($totalrow == 1) df_make_notification("success", "1 document has been deleted successfully");
			else df_make_notification("success", "$totalrow documents have been deleted successfully");
		}
		else df_make_notification("failed", "Failed to delete the selected documents");
		df_go_to_admin_page('panel.php?a=domain&s_a=domain&s_s_a=document&client_id='.$client_id);
	}
	
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>