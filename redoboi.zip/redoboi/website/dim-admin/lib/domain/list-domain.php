<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Client Domain List</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Client Domain List</h5>
		<span>Here you can see the list of your clients domain</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	if(isset($_GET['f_keyword'])) $f_keyword = df_proc_input($_GET['f_keyword']); else $f_keyword = '';

	$item_num = 10;
	$path = 'panel.php?a=domain&s_a=domain';	
	$q_main_display = "SELECT * FROM client_domain WHERE 1 = 1";
	if($f_keyword != '') {$path .= "&f_keyword=$f_keyword"; $q_main_display .= " AND (name LIKE '%$f_keyword%')";}
	$q_main_display .= " ORDER BY id DESC";
	
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysqli_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>

<!-- BULKACTION FUNCTION -->
<script type = "text/javascript">
function bulkaction_check()
{
	var is_check = document.getElementById("masterCheck").checked;
	var bulked = document.forms['bulkaction-form']['domain_list[]'];
	
	if(is_check)
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = true;
	}
	else
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = false;		
	}
}
</script>

<form method = "post" enctype = "multipart/form-data" action = "lib/domain/do-filter-domain.php">
	<ul class="options-bar customed">
		<li>
			<div class="bar-select pull-left">		
				<input type = "text" name = "filter_keyword" id = "filter_keyword" placeholder = "Masukkan kata kunci..." <?php if($f_keyword != '') echo 'value = "'.$f_keyword.'"'; ?>></input>
			</div>
			
			<div class="bar-button">
				<button type="submit" class="btn btn-info" name = "domain_filter_submit" value="submit">Submit</button>
			</div>
		</li>	
	</ul>
</form>
<!-- Table with footer -->
<form action = "lib/domain/do-bulkaction-domain.php" id = "bulkaction-form" name = "bulkaction-form" method = "post" enctype = "multipart/form-data" onsubmit = "return confirm('Are you sure?')">
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>Domain List</h6>
			<div class="nav pull-right">
				<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
				<ul class="dropdown-menu pull-right">
					<li><a href="panel.php?a=domain&s_a=domain&t=add"><i class="icon-plus"></i>Add New Domain</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped table-checks">
			<thead>
				<tr>
					<th style = "width: 2%;"><input type="checkbox" name="checkRow" id = "masterCheck" onclick = "bulkaction_check()"/></th>
					<th style = "width: 5%;">No</th>
					<th style = "width: 22%;">Client Name</th>
					<th style = "width: 22%;">Cpanel Details</th>
					<th style = "width: 18%;">Contact</th>
					<th style = "width: 15%;">Domain Lifespan</th>
					<th style = "width: 15%;">Documents</th>
					<th style = "width: 5%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysqli_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysqli_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><input type="checkbox" name="domain_list[]" value = "<?php echo df_proc_output($row['id']); ?>"/></td>
									<td><?php echo $no; ?></td>
									<td>
										<?php echo ucwords(df_proc_output($row['name'])); ?><br/>
										<i class = "fam-world"></i>&nbsp;<a href = "<?php echo df_proc_output($row['website_url']); ?>" class = "tip" target = "_blank" title = "Visit Website"><?php echo df_proc_output($row['website_url']); ?></a>
									</td>
									<td>
										<a href = "<?php echo df_proc_output($row['cp_url']); ?>" class = "tip" target = "_blank" title = "Visit Website Cpanel"><?php echo df_proc_output($row['cp_url']); ?></a><br/>
										Username: <b><?php echo df_proc_output($row['cp_username']); ?></b><br/>
										Password: <b><?php echo df_proc_output($row['cp_password']); ?></b>
									</td>
									<td>
										Person: <?php if($row['person_name'] != '') echo '<b>'.ucwords(df_proc_output($row['person_name'])).'</b>'; else echo '---'; ?><br/>
										Phone: <?php if($row['person_phone'] != '') echo '<b>'.df_proc_output($row['person_phone']).'</b>'; else echo '---'; ?>
									</td>
									<td>
										Start: <?php if($row['domain_start_date'] != '0000-00-00') echo '<b class = "cl-green">'.date('d/m/Y', strtotime($row['domain_start_date'])).'</b>'; else echo '---'; ?><br/>
										Expired: <?php if($row['domain_exp_date'] != '0000-00-00') echo '<b class = "cl-red">'.date('d/m/Y', strtotime($row['domain_exp_date'])).'</b>'; else echo '---'; ?>
										<?php
											if($row['domain_exp_date'] != '0000-00-00')
											{
												$days_diff = df_get_days_diff(date('Y-m-d'), $row['domain_exp_date']);
												if($days_diff >= 30) echo '<span class = "label label-success">'.$days_diff.' days left</span><br/>';
												else if($days_diff < 30 && $days_diff > 0) echo '<span class = "label label-warning">'.$days_diff.' days left</span><br/>';
												else echo '<span class = "label label-important">Already Expired</span><br/>';
											}
										?>
										<br/>
										Provider: 
										<?php
											if($row['hosting_provider_id'] != 0)
											{
												$provider_name = df_single_query_id_based('hosting_provider', 'name', $row['hosting_provider_id']);
												$provider_url = df_single_query_id_based('hosting_provider', 'url', $row['hosting_provider_id']);
												?> <b><a href = "<?php echo df_proc_output($provider_url); ?>" title = "Visit <?php echo ucwords(df_proc_output($provider_name)); ?> Website" target = "_blank" class = "tip"><?php echo ucwords(df_proc_output($provider_name)); ?></a></b> <?php 
											}
											else echo '---';
										?>
									</td>
									<td>
										<i class = "fam-folder-page"></i>
										<?php
											$doc_num = df_count_query_id_based('domain_document', 'client_id', $row['id']);
											echo '<b>'.$doc_num.' document(s)</b>';
										?>
										<br>
										<a href = "panel.php?a=domain&s_a=domain&s_s_a=document&client_id=<?php echo $row['id']; ?>">See Document</a>
									</td>
									<td>
										<ul class="table-controls">
											<li><a href="panel.php?a=domain&s_a=domain&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit Domain"><i class="fam-pencil"></i></a> </li>
											<li><a href="lib/domain/do-delete-domain.php?id=<?php echo $row['id']; ?>" class="tip" title="Delete Domain" onclick = "return confirm('Are you sure you want to delete this domain?')"><i class="fam-cross"></i></a> </li>
										</ul>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "8" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysqli_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysqli_num_rows($result);
					$res_tot = mysqli_query($q_main_display);
					$tot_num = mysqli_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "8" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysqli_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<div class="table-actions">
						<label>Apply action:</label>
						<select class="styled">
							<option value="">Select action...</option>
							<option value="Delete">Delete Selected Providers</option>
						</select>
						&nbsp;&nbsp;<input type = "submit" class="btn btn-info" value = "Submit">
					</div>
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
</form>
<!-- /table with footer -->