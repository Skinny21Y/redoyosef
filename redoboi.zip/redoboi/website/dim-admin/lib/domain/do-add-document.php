<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	date_default_timezone_set("Asia/Jakarta");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(!isset($_POST['add_document_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{
			$client_id = df_proc_input($_POST['client_id']); 
			$name = df_proc_input($_POST['name']); 
			
			if(df_is_document_exist("pdfdoc"))
			{
				$doc_temp_name = $name;
				
				$doc_new_name = df_upload_document("pdfdoc", "document", "domain", $doc_temp_name);
				$last_update = date('Y-m-d');
						
				$q_add = "INSERT INTO domain_document(client_id, name, file_name, last_update) 
						  VALUES('$client_id', '$name', '$doc_new_name', '$last_update')";
				mysqli_query($q_add);
				
				$affrow = mysqli_affected_rows();
				if($affrow == 1)
				{				
					df_make_notification('success', 'New document has been added successfully');
				}
				else df_make_notification('failed', 'Failed to add new document');
			}
			else df_make_notification('failed', 'Failed to add new document');
		}
		df_go_to_admin_page('panel.php?a=domain&s_a=domain&s_s_a=document&client_id='.$client_id);
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>