<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		$totalrow = 0;
		for ($i = 0; $i < count($_POST['domain_list']); $i++)
		{
			$id = $_POST['domain_list'][$i];
			
			$res_doc = mysqli_query("SELECT file_name FROM domain_document WHERE client_id = '$id'");
			if(mysqli_num_rows($res_doc) > 0)
			{
				while($row_doc = mysqli_fetch_array($res_doc))
				{
					$doc_name = $row_doc['file_name'];
					if($doc_name != '') df_delete_document('document', 'domain', $doc_name); 
				}
			}
			mysqli_query("DELETE FROM domain_document WHERE client_id = '$id'");
			
			$q_delete = "DELETE FROM client_domain WHERE id = '$id'";
			mysqli_query($q_delete);
			
			$affrow = mysqli_affected_rows();
			$totalrow = $totalrow + $affrow;
		}  
		
		if($totalrow > 0) 
		{
			if($totalrow == 1) df_make_notification("success", "1 domain has been deleted successfully");
			else df_make_notification("success", "$totalrow domains have been deleted successfully");
		}
		else df_make_notification("failed", "Failed to delete the selected domains");
		df_go_to_admin_page('panel.php?a=domain&s_a=domain');
	}
	
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>