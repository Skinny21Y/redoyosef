<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(isset($_POST['domain_filter_submit']))
		{
			if(isset($_POST['filter_keyword'])) $f_keyword = df_proc_input($_POST['filter_keyword']); else $f_keyword = '';
			
			$red_url = 'panel.php?a=domain&s_a=domain';
			if($f_keyword != '') $red_url .= '&f_keyword='.$f_keyword;
			df_go_to_admin_page($red_url);
		}
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>