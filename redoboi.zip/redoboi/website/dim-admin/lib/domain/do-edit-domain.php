<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(!isset($_POST['edit_domain_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{		
			$id = df_proc_input($_POST['id']);	
			$hosting_provider_id = df_proc_input($_POST['hosting_provider_id']); 
			$name = df_proc_input($_POST['name']); 
			$website_url = df_proc_input($_POST['website_url']); 
			$person_name = df_proc_input($_POST['person_name']); 
			$person_phone = df_proc_input($_POST['person_phone']); 
			$cp_url = df_proc_input($_POST['cp_url']); 
			$cp_username = df_proc_input($_POST['cp_username']); 
			$cp_password = df_proc_input($_POST['cp_password']); 
			$domain_start_date = df_convert_date(df_proc_input($_POST['domain_start_date']), 'dd/mm/yyyy', 'yyyy-mm-dd');
			$domain_exp_date = df_convert_date(df_proc_input($_POST['domain_exp_date']), 'dd/mm/yyyy', 'yyyy-mm-dd');
			
			$res_name = mysqli_query("SELECT id FROM client_domain WHERE name = '$name' AND id <> '$id'");
			if(mysqli_num_rows($res_name) > 0)
			{
				df_make_notification('failed', "The client domain named '$name' has been already added");
				df_go_to_admin_page('panel.php?a=domain&s_a=domain&t=edit&id='.$id);
			}
			else
			{
				$q_update = "UPDATE client_domain SET hosting_provider_id = '$hosting_provider_id', name = '$name', 
							 website_url = '$website_url', person_name = '$person_name', person_phone = '$person_phone',
							 cp_url = '$cp_url', cp_username = '$cp_username', cp_password = '$cp_password',
							 domain_start_date = '$domain_start_date', domain_exp_date = '$domain_exp_date'
							 WHERE id = '$id'";
				mysqli_query($q_update);
				
				$affrow = 0;
				$affrow = mysqli_affected_rows();
				if($affrow == 0 || $affrow == 1) df_make_notification('success', 'The selected domain has been updated successfully');
			}
		}
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>