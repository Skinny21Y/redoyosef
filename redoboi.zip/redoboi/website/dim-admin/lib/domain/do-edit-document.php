<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	date_default_timezone_set("Asia/Jakarta");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		if(!isset($_POST['edit_document_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{		
			$id = df_proc_input($_POST['id']);	
			$client_id = df_proc_input($_POST['client_id']);		
			$name = df_proc_input($_POST['name']); 
			$last_update = date('Y-m-d');
			
			$q_update = "UPDATE domain_document SET name = '$name', last_update = '$last_update' WHERE id = '$id'";
			mysqli_query($q_update);
			
			$affrow = 0;
			$affrow = mysqli_affected_rows();
			
			if(df_is_document_exist("pdfdoc"))
			{
				$doc_temp_name = $name;
				
				$doc_old_name = df_proc_input($_POST['old_doc']);
				$doc_new_name = df_upload_document("pdfdoc", "document", "domain", $doc_temp_name);					
				
				mysqli_query("UPDATE domain_document SET file_name = '$doc_new_name' WHERE id = '$id'");
				
				$affrow2 = mysqli_affected_rows();
				if($affrow2 == 1)
				{				
					if($doc_old_name != '') df_delete_document("document", "domain", $doc_old_name);
				}
			}	
			if($affrow == 0 || $affrow == 1) df_make_notification('success', 'The selected document has been updated successfully');
			df_go_to_admin_page('panel.php?a=domain&s_a=domain&s_s_a=document&client_id='.$client_id);			
		}
	}
	df_go_to_admin_page('panel.php?a=domain&s_a=domain');
?>