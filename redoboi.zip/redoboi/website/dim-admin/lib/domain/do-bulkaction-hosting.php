<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		$totalrow = 0;
		for ($i = 0; $i < count($_POST['hosting_list']); $i++)
		{
			$id = $_POST['hosting_list'][$i];
			
			mysqli_query("UPDATE client_domain SET hosting_provider_id = '0' WHERE hosting_provider_id = '$id'");
			$q_delete = "DELETE FROM hosting_provider WHERE id = '$id'";
			mysqli_query($q_delete);
			
			$affrow = mysqli_affected_rows();
			$totalrow = $totalrow + $affrow;
		}  
		
		if($totalrow > 0) 
		{
			if($totalrow == 1) df_make_notification("success", "1 hosting provider has been deleted successfully");
			else df_make_notification("success", "$totalrow hosting providers have been deleted successfully");
		}
		else df_make_notification("failed", "Failed to delete the selected hosting providers");
		df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
	}
	
	df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
?>