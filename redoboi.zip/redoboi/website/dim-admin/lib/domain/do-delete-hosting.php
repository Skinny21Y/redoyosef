<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{	
		$id = df_proc_input($_GET['id']);
		
		mysqli_query("UPDATE client_domain SET hosting_provider_id = '0' WHERE hosting_provider_id = '$id'");
		$q_update = "DELETE FROM hosting_provider WHERE id = '$id'";
		mysqli_query($q_update);
		$affrow = mysqli_affected_rows();
		
		if($affrow == 1) df_make_notification("success", "The selected hosting provider has been deleted successfully");
		else df_make_notification("failed", "Failed to delete the selected hosting provider");
		
		if(strpos($_SESSION[$page_session_key], "a=domain&s_a=hosting") !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
		else df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
	}	
	else df_go_to_admin_page('panel.php');
?>