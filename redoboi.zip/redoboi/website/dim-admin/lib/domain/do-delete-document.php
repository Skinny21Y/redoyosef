<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{	
		$client_id = df_proc_input($_GET['client_id']);
		$id = df_proc_input($_GET['id']);
		
		$res = mysqli_query("SELECT file_name FROM domain_document WHERE id = '$id'");
		if(mysqli_num_rows($res) > 0) 
		{
			$row = mysqli_fetch_array($res); 
			$doc_name = $row['file_name'];
			if($doc_name != '') df_delete_document('document', 'domain', $doc_name);
		}
		
		$q_update = "DELETE FROM domain_document WHERE id = '$id'";
		mysqli_query($q_update);
		$affrow = mysqli_affected_rows();
		if($affrow == 1) df_make_notification("success", "The selected document has been deleted successfully");
		else df_make_notification("failed", "Failed to delete the selected document");
		
		if(strpos($_SESSION[$page_session_key], "a=domain&s_a=domain&s_s_a=document&client_id=".$client_id) !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
		else df_go_to_admin_page('panel.php?a=domain&s_a=domain');
	}	
	else df_go_to_admin_page('panel.php');
?>