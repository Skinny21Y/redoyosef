<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('dom'))
	{
		$id = df_proc_input($_GET['id']);
		$act = df_proc_input($_GET['a']);
					
		$res = mysqli_query("SELECT name, file_name FROM domain_document WHERE id = '$id'");
		if(mysqli_num_rows($res) > 0)
		{
			$row = mysqli_fetch_array($res);
			
			$file = $_SERVER['DOCUMENT_ROOT'].$root_preurl.'/document/domain/'.$row['file_name'];
			
			if (file_exists($file)) 
			{
				header('Content-Description: File Transfer');
				header('Content-Type: application/pdf');
				
				if($act == 'view') header('Content-Disposition: inline; filename='.df_get_slug($row['name'])).'.pdf';
				else if($act == 'download') header('Content-Disposition: attachment; filename='.df_get_slug($row['name'])).'.pdf';
				
				header('Content-Transfer-Encoding: binary');
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($file));
				ob_clean();
				flush();
				readfile($file);
				exit;
			}
		}
		else exit;
	}
?>