<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('user'))
	{	
		$id = df_proc_input($_GET['id']);
		
		$res = mysql_query("SELECT pic FROM user WHERE id = '$id'");
		if(mysql_num_rows($res) > 0) 
		{
			$row = mysql_fetch_array($res); 
			$image_name = $row['pic'];
			if($image_name != '') df_delete_image('admin-pic', $image_name);
		}
		
		$q_update = "UPDATE user SET pic = '', pic_alt = '' WHERE id = '$id'";
		mysql_query($q_update);
		$affrow = mysql_affected_rows();
		if($affrow == 1) df_make_notification("success", "The selected user's picture been removed successfully");
		else df_make_notification("failed", "Failed to remove the selected user's picture");
		
		if(strpos($_SESSION[$page_session_key], "a=user&s_a=user") !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
		else df_go_to_admin_page('panel.php?a=user&s_a=user');
	}	
	else df_go_to_admin_page('panel.php');
?>