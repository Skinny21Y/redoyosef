<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	df_check_user_session();
	if(df_have_privilege('all'))
	{
		if(!isset($_POST['add_privilege_submit'])) 
		{
			df_make_notification('failed', 'Please fill the details below'); 
			df_go_to_admin_page('panel.php?a=user&s_a=privilege&t=add');
		}
		else
		{
			$name = df_proc_input($_POST['name']);
			
			$res = mysql_query("SELECT id FROM user_privilege WHERE name = '$name'");
			if(mysql_num_rows($res) > 0)
			{
				df_make_notification('failed', "The privilege named $name has been already used");
				df_go_to_admin_page('panel.php?a=user&s_a=privilege&t=add');
			}
			else
			{
				$privilege = '';
				foreach($_POST['privilege'] as $pri)
				{
					$formatted = "#".$pri."|";
					$privilege .= $formatted;
				}
				if($privilege != '')
				{
					$q_add = "INSERT INTO user_privilege(name, privilege) VALUES('$name', '$privilege')";
					mysql_query($q_add);
					
					$affrow = mysql_affected_rows();
					if($affrow == 1) df_make_notification("success", "New privilege has been added successfully");
					else df_make_notification("failed", "Failed to add new privilege");
				}
				else 
				{
					df_make_notification('failed', 'Please select the access list');
					df_go_to_admin_page('panel.php?a=user&s_a=privilege&t=add');
				}
			}
		}
	}
	df_go_to_admin_page('panel.php?a=user&s_a=privilege');
?>