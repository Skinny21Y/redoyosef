<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Users List</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Users List</h5>
		<span>Here you can see the list of users serve as the website administrator</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	$my_user_id = $_SESSION[$dc_user_id];
	
	$item_num = 10;
	$path = 'panel.php?a=user&s_a=user';	
	if(df_have_privilege('all')) $q_main_display = "SELECT * FROM user WHERE id <> '$my_user_id' ORDER BY id ASC";
	else $q_main_display = "SELECT * FROM user WHERE id <> '$my_user_id' AND privilege <> '1' ORDER BY id ASC";
	
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysqli_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>
              
<!-- Table with footer -->
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>Users List</h6>
			<div class="nav pull-right">
				<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
				<ul class="dropdown-menu pull-right">
					<li><a href="panel.php?a=user&s_a=user&t=add"><i class="icon-plus"></i>Add New User</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th style = "width: 10%;">No</th>
					<th style = "width: 10%;">Picture</th>
					<th style = "width: 25%;">Profile Details</th>
					<th style = "width: 20%;">Email Address</th>					
					<th style = "width: 15%;">Status</th>			
					<th style = "width: 15%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysqli_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysqli_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><?php echo $no; ?></td>
									<td>
										<?php
											if($row['pic'] != '') 
											{ 
												?> 
													<a href = "<?php echo $images_preurl; ?>/admin-pic/<?php echo $row['pic']; ?>" class = "lightbox">
														<img src = "<?php echo $images_preurl; ?>/admin-pic/<?php echo $row['pic']; ?>">
													</a>
													<?php
													if($row['privilege'] != 1)
													{
														?>
														<ul class = "list-font" style = "margin-top: 5px;">
															<li><i class="fam-cross"></i><a href = "lib/user/do-delete-user-pic.php?id=<?php echo $row['id']; ?>" class = "cust-pad delete" onclick = "return confirm('Are you sure you want to remove this user\'s current picture?')">Remove</a></li>
														</ul>
														<?php
													}
											}
											else { ?> <a href = "<?php echo $images_preurl; ?>/default/no-photo.jpg" class = "lightbox"><img src = "<?php echo $images_preurl; ?>/default/no-photo.jpg"></a> <?php }
										?>
									</td>
									<td>
										Name: <b><?php if($row['name'] != '') echo ucwords(df_proc_output($row['name'])); else echo '---'; ?></b><br/>
										Phone: <b><?php if($row['phone'] != '') echo ucwords(df_proc_output($row['phone'])); else echo '---'; ?></b><br/>
										Username: <b><i><?php echo df_proc_output($row['username']); ?></i></b><br/>
										Privilege: 
											<span class="label label-info">
												<?php 
													$pri_name = ucwords(df_proc_output(df_single_query_id_based('user_privilege', 'name', $row['privilege'])));
													if($pri_name != '') echo $pri_name; 
													else echo '---';
												?>
											</span>
									</td>
									<td>
										<a href = "mailto:<?php echo strtolower(df_proc_output($row['email'])); ?>" title = "Send Email" class = "tip"><?php echo strtolower(df_proc_output($row['email'])); ?></a><br/>
									</td>
									<td>
										<?php 
											if($row['is_active'] == 'yes') { ?> <span class="label label-success">Active</span> <?php }
											else { ?> <span class="label label-important">Not Active</span> <?php }
										?>
									</td>
									<td>
										<?php
											if($row['privilege'] == 1) { ?> <i class = "fam-lock"></i>&nbsp;<b><i>Restricted</i></b><?php }
											else 
											{ 
											?> 
												<ul class="table-controls">
													<li><a href="panel.php?a=user&s_a=user&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit User"><i class="fam-pencil"></i></a> </li>
													<li><a href="lib/user/do-delete-user.php?id=<?php echo $row['id']; ?>" class="tip" title="Delete User" onclick = "return confirm('Are you sure you want to delete this user?')"><i class="fam-cross"></i></a> </li>
												</ul>
											<?php 
											}
										?>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "6" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysqli_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysql_num_rows($result);
					$res_tot = mysqli_query($q_main_display);
					$tot_num = mysqli_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "6" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysqli_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
<!-- /table with footer -->