<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=user&s_a=privilege">User Privilege List</a></li>
		<li class = "active"><a>Add New Privilege</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Add New Privilege</h5>
		<span>Here you can add a new privilege for your administrators</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/user/do-add-privilege.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>
				<div class="control-group">
					<label class="control-label">Privilege Name: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="name" id="name">
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Access List: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<select data-placeholder="Choose the access available for this privilege..." class="validate[required] select" multiple="multiple" tabindex = "6" name = "privilege[]">
								<option value = "conf">Website Configuration</option>
								<option value = "user">User Management</option>
								<option value = "dom">Clients Domain</option>
							</select>  
						</span>
					</div>
				</div>
								
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "add_privilege_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>