<?php	
	$id = df_proc_input($_GET['id']);
	$data = df_general_query_id("user", $id);
?>

<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=user&s_a=user">Users List</a></li>
		<li class = "active"><a>Edit User</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

	<?php
	if($data != false)
	{
		?>		
			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5></h5>
					<span>Here you can edit the detail of the selected user</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/user/do-edit-user.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<input type = "hidden" name = "id" value = "<?php echo df_proc_output($data['id']); ?>">
					<input type = "hidden" name = "old_pic" value = "<?php echo df_proc_output($data['pic']); ?>">
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>
							<div class="control-group">
								<label class="control-label">Username: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required] span12" name="username" id="username" value = "<?php echo df_proc_output($data['name']); ?>">
										<span class="help-block">Username will be used to login</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Additional Info: </label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="span12" name="name" id="name" value = "<?php echo ucwords(df_proc_output($data['name'])); ?>">
										<span class="help-block">Full Name (optional)</span>
									</span>
									<span class = "span6">
										<input type="text" class="span12" name="phone" id="phone" value = "<?php echo df_proc_output($data['phone']); ?>">
										<span class="help-block">Phone Number (optional)</span>
									</span>
								</div>
							</div>
				
							<div class="control-group">
								<label class="control-label">Email Address: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required, custom[email]] span12" name="email" id="email" value = "<?php echo strtolower(df_proc_output($data['email'])); ?>">
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Password: </label>
								<div class="controls">
									<span class = "span6">
										<input type="password" class="span12" name="new_password" id="new_password">
										<span class="help-block">Ignore if you do not want to change the old password</span>
									</span>		
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Confirm Password: </label>
								<div class="controls">
									<span class = "span6">
										<input type="password" class="validate[equals[new_password]] span12" name="conf_password" id="conf_password">
									</span>		
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Privilege: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">							
										<select name="privilege" class="validate[required] styled">
											<?php
												$res_pri = mysql_query("SELECT * FROM user_privilege WHERE id <> 1 ORDER BY id ASC");
												if(mysql_num_rows($res_pri) > 0)
												{
													while($row_pri = mysql_fetch_array($res_pri))
													{
														?>
															<option value = "<?php echo $row_pri['id']; ?>" <?php if($data['privilege'] == $row_pri['id']) echo 'selected = "selected"'; ?>><?php echo ucwords(df_proc_output($row_pri['name'])); ?></option>
														<?php
													}
												}
											?>
										</select>
									</span>		
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">User Status: </label>
								<div class="controls">
									<span class = "span6">	
										<label class="radio inline">
											<input type="radio" id="status_a" class="styled" value="yes" name = "is_active" <?php if($data['is_active'] == 'yes') echo 'checked'; ?>>
											Active
										</label>
										<label class="radio inline">
											<input type="radio" id="status_n" class="styled" value="no" name = "is_active" <?php if($data['is_active'] == 'no') echo 'checked'; ?>>
											Not Active
										</label>
									</span>		
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">
									Picture (optional):
									<?php
										if($data['pic'] != '')
										{
											?>
												<br/>
												<ul class = "list-font">
													<li>
														<i class="fam-photo"></i>
														<a href = "<?php echo $images_preurl; ?>/admin-pic/<?php echo $data['pic']; ?>" class = "cust-pad regular lightbox">
															See Current Picture
														</a>
													</li>
												</ul>
											<?php
										}
									?>
								</label>
								<div class="controls">
									<span class = "span6">
										<input type="file" class="validate[custom[imageGeneral]]" name = "pic" id = "pic">
										<span class="help-block">Only .jpg, .jpeg, or .png allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Picture Alternate Text: </label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt" value = "<?php echo ucwords(df_proc_output($data['pic_alt'])); ?>">
									</span>
								</div>
							</div>
															
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "edit_user_submit" value = "Submit">
							</div>
						</div>
					</div>
				</fieldset>
			</form>
		<?php
	}	
	else
	{
		?>
		<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>The page is not found</h5>
					<span>Please go back to the <a href = "panel.php?a=user&s_a=user">users list</a> page.</span>
				</div>
			</div><br/>
		<!-- /page header -->
		<?php
	}
?>