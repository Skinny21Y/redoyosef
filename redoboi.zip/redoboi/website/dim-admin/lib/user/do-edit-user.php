<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(!isset($_POST['edit_user_submit'])) df_make_notification('failed', 'Please fill the details below');
	else
	{
		$id = df_proc_input($_POST['id']); 
		$name = df_proc_input($_POST['name']); 
		$phone = df_proc_input($_POST['phone']); 
		$username = df_proc_input($_POST['username']); 
		$email = df_proc_input($_POST['email']); 
		$privilege = df_proc_input($_POST['privilege']); 
		$is_active = df_proc_input($_POST['is_active']);
		
		$res_username = mysql_query("SELECT id FROM user WHERE username = '$username' AND id <> $id");
		if(mysql_num_rows($res_username) > 0)
		{
			df_make_notification('failed', "The username '$username' has been already used");
			df_go_to_admin_page('panel.php?a=user&s_a=user&t=edit&id='.$id);
		}
		else
		{
			$q_update = "UPDATE user SET name = '$name', phone = '$phone', username = '$username', email = '$email', privilege = '$privilege', is_active = '$is_active'
					     WHERE id = '$id'";
			mysql_query($q_update);
			$affrow = 0;
			$affrow = mysql_affected_rows();

			if($_POST['new_password'] != '')
			{
				$password = md5($_POST['new_password']);
				mysql_query("UPDATE user SET password = '$password' WHERE id = '$id'");
			}
			if(df_is_image_exist("pic"))
			{
				$document_name = $_FILES['pic']['name'];
				$document_extension = strtolower(df_get_document_extension($document_name));
				if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png')
				{
					$pic_alt = df_proc_input($_POST['pic_alt']); 
					if($pic_alt != '') $pic_temp_name = $pic_alt;
					else $pic_temp_name = $username;
					
					$pic_old_name = df_proc_input($_POST['old_pic']);
					$pic_new_name = df_upload_image("pic", "admin-pic", $pic_temp_name);				
					
					mysql_query("UPDATE user SET pic = '$pic_new_name', pic_alt = '$pic_alt' WHERE id = '$id'");
					$affrow_pic = mysql_affected_rows();
					if($affrow_pic == 1)
					{				
						if($pic_old_name != '') df_delete_image("admin-pic", $pic_old_name);
					}
				}
			}

			if($affrow == 0 || $affrow == 1) df_make_notification('success', 'The selected user has been updated successfully');
			if(strpos($_SESSION[$page_session_key], "a=user&s_a=user") !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
		}
	}
	df_go_to_admin_page('panel.php?a=user&s_a=user');
?>