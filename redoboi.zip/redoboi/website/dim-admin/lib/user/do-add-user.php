<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(!isset($_POST['add_user_submit'])) df_make_notification('failed', 'Please fill the details below');
	else
	{
		$name = df_proc_input($_POST['name']); 
		$phone = df_proc_input($_POST['phone']); 
		$username = df_proc_input($_POST['username']); 
		$email = df_proc_input($_POST['email']); 
		$password = md5($_POST['new_password']); 
		$privilege = df_proc_input($_POST['privilege']); 
		$is_active = df_proc_input($_POST['is_active']); 
		$pic_alt = df_proc_input($_POST['pic_alt']); 
		
		$res_username = mysql_query("SELECT id FROM user WHERE username = '$username'");
		if(mysql_num_rows($res_username) > 0)
		{
			df_make_notification('failed', "The username '$username' has been already used");
			df_go_to_admin_page('panel.php?a=user&s_a=user&t=add');
		}
		else
		{
			$affrow = 0;
			
			if(df_is_image_exist("pic"))
			{
				$document_name = $_FILES['pic']['name'];
				$document_extension = strtolower(df_get_document_extension($document_name));
				if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png')
				{
					if($pic_alt != '') $pic_temp_name = $pic_alt;
					else $pic_temp_name = $username;
					
					$pic_new_name = df_upload_image("pic", "admin-pic", $pic_temp_name);
							
					$q_add = "INSERT INTO user(name, phone, username, email, password, privilege, is_active, pic, pic_alt) 
							  VALUES('$name', '$phone', '$username', '$email', '$password', '$privilege', '$is_active', '$pic_new_name', '$pic_alt')";
					mysql_query($q_add);
					
					$affrow = mysql_affected_rows();
					if($affrow == 1)
					{				
						df_make_notification('success', 'New user has been added successfully');
					}
					else df_make_notification('failed', 'Failed to add new user');
				}
			}	
			else
			{			
				$q_add = "INSERT INTO user(name, phone, username, email, password, privilege, is_active) 
						  VALUES('$name', '$phone', '$username', '$email', '$password', '$privilege', '$is_active')";
				mysql_query($q_add);
				
				$affrow = mysql_affected_rows();
				if($affrow == 1)
				{				
					df_make_notification('success', 'New user has been added successfully');
				}
				else df_make_notification('failed', 'Failed to add new user');
			}
		}
	}
	df_go_to_admin_page('panel.php?a=user&s_a=user');
?>