<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=user&s_a=user">Users List</a></li>
		<li class = "active"><a>Add New User</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Add New User</h5>
		<span>Here you can add a new user to server as your website administrator</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/user/do-add-user.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>				
				<div class="control-group">
					<label class="control-label">Username: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="username" id="username">
							<span class="help-block">Username will be used to login</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Additional Info: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="span12" name="name" id="name">
							<span class="help-block">Full Name (optional)</span>
						</span>
						<span class = "span6">
							<input type="text" class="span12" name="phone" id="phone">
							<span class="help-block">Phone Number (optional)</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Email Address: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required, custom[email]] span12" name="email" id="email">
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Password: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="password" class="validate[required, minSize[6]] span12" name="new_password" id="new_password">
							<span class="help-block">Min: 6 characters allowed</span>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Confirm Password: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="password" class="validate[required, minSize[6], equals[new_password]] span12" name="conf_password" id="conf_password">
							<span class="help-block">Min: 6 characters allowed</span>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Privilege: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">							
							<select name="privilege" class="validate[required] styled" >
								<option value = "">--- Select Privilege ---</option>
								<?php
									$res_pri = mysql_query("SELECT * FROM user_privilege WHERE id <> 1 ORDER BY id ASC");
									if(mysql_num_rows($res_pri) > 0)
									{
										while($row_pri = mysql_fetch_array($res_pri))
										{
											?>
												<option value = "<?php echo $row_pri['id']; ?>"><?php echo ucwords(df_proc_output($row_pri['name'])); ?></option>
											<?php
										}
									}
								?>
							</select>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">User Status: </label>
					<div class="controls">
						<span class = "span6">	
							<label class="radio inline">
								<input type="radio" id="status_a" class="styled" value="yes" name = "is_active" checked>
								Active
							</label>
							<label class="radio inline">
								<input type="radio" id="status_n" class="styled" value="no" name = "is_active">
								Not Active
							</label>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">
						Picture (optional):
					</label>
					<div class="controls">
						<span class = "span6">
							<input type="file" class="validate[custom[imageGeneral]]" name = "pic" id = "pic">
							<span class="help-block">Only .jpg, .jpeg, or .png allowed</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Picture Alternate Text: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt">
						</span>
					</div>
				</div>
												
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "add_user_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>