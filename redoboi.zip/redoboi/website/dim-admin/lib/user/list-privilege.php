<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>User Privilege List</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>User Privilege List</h5>
		<span>Here you can see the list of privilege available for your administrators</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	$item_num = 10;
	$path = 'panel.php?a=user&s_a=privilege';	
	$q_main_display = "SELECT * FROM user_privilege ORDER BY id ASC";
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysqli_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>
              
<!-- Table with footer -->
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>User Privilege List</h6>
			<?php
			if(df_have_privilege('all'))
			{
			?>
				<div class="nav pull-right">
					<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
					<ul class="dropdown-menu pull-right">
						<li><a href="panel.php?a=user&s_a=privilege&t=add"><i class="icon-plus"></i>Add New Privilege</a></li>
					</ul>
				</div>
			<?php
			}
			?>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th style = "width: 10%;">No</th>
					<th style = "width: 20%;">Privilege Name</th>
					<th style = "width: 50%;">Access</th>
					<th style = "width: 15%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysqli_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysqli_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><?php echo $no; ?></td>
									<td><?php echo ucwords(df_proc_output($row['name'])); ?></td>
									<td>
										<?php
											$privilege_list = df_grouping_privilege($row['privilege']);
											
											if(!empty($privilege_list))
											{
												$sep = 0;
												foreach($privilege_list as $privilege_access)
												{
													$sep++;
													if($privilege_access == 'all') $access_full_name = 'All';
													else if($privilege_access == 'conf') $access_full_name = 'Website Configuration';
													else if($privilege_access == 'user') $access_full_name = 'User Management';
													else if($privilege_access == 'dom') $access_full_name = 'Clients Domain';
													else continue;
													
													if($sep > 1) { ?> | <span class="label label-success"><?php echo ucwords(df_proc_output($access_full_name)); ?></span><?php }
													else { ?> <span class="label label-success"><?php echo ucwords(df_proc_output($access_full_name)); ?></span><?php }
												}
											}
										?>
									</td>
									<td>
										<?php
											if($row['id'] == 1 || !df_have_privilege('all')) { ?> <i class = "fam-lock"></i>&nbsp;<b><i>Restricted</i></b><?php }
											else 
											{ 
											?> 
												<ul class="table-controls">
													<li><a href="panel.php?a=user&s_a=privilege&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit Privilege"><i class="fam-pencil"></i></a> </li>
													<li><a href="lib/user/do-delete-privilege.php?id=<?php echo $row['id']; ?>" class="tip" title="Delete Privilege" onclick = "return confirm('Are you sure you want to delete this privilege?\nAll users with this privilege will be unable to login unless you change their privilege')"><i class="fam-cross"></i></a> </li>
												</ul>
											<?php 
											}
										?>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "4" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysqli_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysql_num_rows($result);
					$res_tot = mysqli_query($q_main_display);
					$tot_num = mysqli_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "4" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysqli_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
<!-- /table with footer -->