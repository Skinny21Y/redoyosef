<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	df_check_user_session();
	if(!isset($_POST['edit_privilege_submit'])) df_make_notification('failed', 'Please fill the details below'); 
	else
	{
		$id = df_proc_input($_POST['id']);
		$name = df_proc_input($_POST['name']);
		
		$res = mysql_query("SELECT id FROM user_privilege WHERE name = '$name' AND id <> '$id'");
		if(mysql_num_rows($res) > 0)
		{
			df_make_notification('failed', "The privilege named $name has been already used");
			df_go_to_admin_page('panel.php?a=user&s_a=privilege&t=edit&id='.$id);
		}
		else
		{		
			$privilege = '';
			foreach($_POST['privilege'] as $pri)
			{
				$formatted = "#".$pri."|";
				$privilege .= $formatted;
			}
			if($privilege != '')
			{
				$q_update = "UPDATE user_privilege SET name = '$name', privilege = '$privilege' WHERE id = '$id'";
				mysql_query($q_update);
				
				$affrow = mysql_affected_rows();
				if($affrow == 0 || $affrow == 1) df_make_notification("success", "The selected privilege has been updated successfully");
				else df_make_notification("failed", "Failed to update the selected privilege");
				
				if(strpos($_SESSION[$page_session_key], "a=user&s_a=privilege") !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
			}
			else 
			{
				df_make_notification('failed', 'Please select the access list');
				df_go_to_admin_page('panel.php?a=user&s_a=privilege&t=edit&id='.$id);
			}
		}
	}
	df_go_to_admin_page('panel.php?a=user&s_a=privilege');
?>