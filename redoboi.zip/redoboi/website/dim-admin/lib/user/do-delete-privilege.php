<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	$id = df_proc_output($_GET['id']);
	$affrow = 0;
	
	if($id != 1 && df_have_privilege('all'))
	{
		$q_delete = "DELETE FROM user_privilege WHERE id = '$id'";
		mysql_query($q_delete);
		$affrow = mysql_affected_rows();
					
		$q_update_user = "UPDATE user SET privilege = '0' WHERE privilege = '$id'";
		mysql_query($q_update_user);
	
		if($affrow == 1) df_make_notification("success", "The selected privilege has been deleted successfully");
		else df_make_notification ("failed", "Failed to delete the selected privilege");
	}
	
	df_go_to_admin_page('panel.php?a=user&s_a=privilege');
?>