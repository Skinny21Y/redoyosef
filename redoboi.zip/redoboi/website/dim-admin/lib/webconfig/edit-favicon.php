<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Change Website Icon</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Change Website Icon</h5>
		<span>Here you can change your website icon</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/webconfig/do-edit-favicon.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<input type = "hidden" name = "old_pic" value = "<?php echo $favicon_config; ?>">
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Select Your Icon</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>							
				<div class="control-group">
					<label class="control-label">
						Website Icon:
						<?php
							if($favicon_config != '')
							{
								?>
									<br/>
									<ul class = "list-font">
										<li><i class="fam-cross"></i><a href = "lib/webconfig/do-delete-favicon.php" class = "cust-pad delete" onclick = "return confirm('Are you sure you want to remove the current website icon?')">Remove Icon</a></li>
									</ul>
								<?php
							}
						?>
					</label>
					<div class="controls">
						<span class = "span6">
							<input type="file" class="validate[custom[imageFavicon]]" name = "pic" id = "pic">
							<span class="help-block">Size: 16px &times; 16px (Only .jpg, .jpeg, .png, or .ico allowed)</span>
						</span>
					</div>
				</div>
				
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "webconfig_favicon_submit" value = "Submit">
				</div>
			</div>
		</div>	
	</fieldset>
</form>