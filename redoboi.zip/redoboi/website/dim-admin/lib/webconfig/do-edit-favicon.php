<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('conf'))
	{	
		if(!isset($_POST['webconfig_favicon_submit'])) df_make_notification('failed', 'Please fill the details below');

		else
		{
			$id = $_SESSION[$dc_user_id];
			
			if(df_is_image_exist("pic"))
			{
				$document_name = $_FILES['pic']['name'];
				$document_extension = strtolower(df_get_document_extension($document_name));
				if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png' || $document_extension == 'ico')
				{
					$pic_temp_name = ucwords($website_name_config).' Favicon';
					
					$pic_old_name = df_proc_input($_POST['old_pic']);
					$pic_new_name = df_upload_image("pic", "favicon", $pic_temp_name);			
					
					mysql_query("UPDATE web_config SET favicon = '$pic_new_name' WHERE id = '$id'");
					
					$affrow = mysql_affected_rows();
					if($affrow == 1)
					{				
						if($pic_old_name != '') df_delete_image("favicon", $pic_old_name);
						df_make_notification('success', 'Your website icon has been changed successfully');
					}
					else df_make_notification('failed', 'Failed to change your website icon');
				}
			}
			else df_make_notification('failed', 'Please select your website icon');
		    df_go_to_admin_page('panel.php?a=webconfig&s_a=favicon');
		}
	}
	else df_go_to_admin_page('panel.php');
?>