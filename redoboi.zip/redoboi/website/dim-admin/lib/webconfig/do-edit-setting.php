<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('conf'))
	{
		if(!isset($_POST['webconfig_setting_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{
			$company_name = df_proc_input($_POST['company_name']);
			$tag_line = df_proc_input($_POST['tag_line']);
			
			/* $address = df_proc_input($_POST['address']);
			$city =df_proc_input($_POST['city']);
			$country =df_proc_input($_POST['country']); */
			
			/* $conper1 = df_proc_input($_POST['conper1']);
			$conper2 = df_proc_input($_POST['conper2']); */
			$phone2 = df_proc_input($_POST['phone2']);
			$phone1 = df_proc_input($_POST['phone1']);
			$phone2 = df_proc_input($_POST['phone2']);
			/* $fax1 = df_proc_input($_POST['fax1']);
			$fax2 = df_proc_input($_POST['fax2']); */
			$email1 = df_proc_input($_POST['email1']);
			$email2 = df_proc_input($_POST['email2']);
			
			/* $facebook_link = df_proc_input($_POST['facebook_link']);
			$twitter_link = df_proc_input($_POST['twitter_link']);
			$linkedin_link = df_proc_input($_POST['linkedin_link']);
			$instagram_link = df_proc_input($_POST['instagram_link']); */
			
			$website_name = df_proc_input($_POST['website_name']);
			$website_url = df_proc_input($_POST['website_url']);
			
			/* $meta_copyright = df_proc_input($_POST['meta_copyright']);
			$meta_keywords = df_proc_input($_POST['meta_keywords']);
			$meta_description = df_proc_input($_POST['meta_description']); */
			
			$q_update = "UPDATE web_config
					     SET company_name = '$company_name', tag_line = '$tag_line',
						 phone1 = '$phone1', phone2 = '$phone2', email1 = '$email1', email2 = '$email2', 
						 website_name = '$website_name', website_url = '$website_url'
						 WHERE id = '1'";
			mysql_query($q_update);
			
			$affrow = mysql_affected_rows();
			
			if($affrow == 1 || $affrow == 0) df_make_notification('success', 'The website general settings have been updated successfully');
			else df_make_notification('failed', 'Failed to update the website general settings');			
		}
		df_go_to_admin_page('panel.php?a=webconfig&s_a=setting');
	}
	else df_go_to_admin_page('panel.php');
?>