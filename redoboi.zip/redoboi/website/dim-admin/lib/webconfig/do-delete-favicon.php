<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('conf'))
	{	
		$id = 1;
		$res = mysql_query("SELECT favicon FROM web_config WHERE id = '$id'");
		if(mysql_num_rows($res) > 0) 
		{
			$row = mysql_fetch_array($res); 
			$image_name = $row['favicon'];
			if($image_name != '') df_delete_image('favicon', $image_name);
		}
		
		$q_update = "UPDATE web_config SET favicon = '' WHERE id = '$id'";
		mysql_query($q_update);
		$affrow = mysql_affected_rows();
		if($affrow == 1) df_make_notification("success", "The website icon has been removed successfully");
		else df_make_notification("failed", "Failed to remove the website icon");
		
		df_go_to_admin_page('panel.php?a=webconfig&s_a=favicon');
	}	
	else df_go_to_admin_page('panel.php');
?>