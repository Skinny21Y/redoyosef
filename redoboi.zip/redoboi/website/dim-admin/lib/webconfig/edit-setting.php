<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Website General Settings</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Website General Settings</h5>
		<span>Here you can change your general website's general settings</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/webconfig/do-edit-setting.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Settings Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>
				<div class="control-group">
					<label class="control-label">Company Details:</label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="company_name" id="company_name" value = "<?php echo ucwords(df_proc_output($company_name_config)); ?>">
							<span class="help-block">Company Name <span class = "text-error">*</span></span>
						</span>
						<span class = "span6">
							<input type="text" class="validate[maxSize[200]] span12" name="tag_line" id="tag_line" value = "<?php echo ucfirst(df_proc_output($tag_line_config)); ?>">
							<span class="help-block">Company Tag Line (optional)</span>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Company Contact: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="phone1" id="phone1" value = "<?php echo df_proc_output($phone1_config); ?>">
							<span class="help-block">Phone Number 1 <span class = "text-error">*</span></span>
						</span>
						<span class = "span6">
							<input type="text" class="span12" name="phone2" id="phone2" value = "<?php echo df_proc_output($phone2_config); ?>">
							<span class="help-block">Phone Number 2 (optional)</span>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Company Email: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required, custom[email]] span12" name="email1" id="email1" value = "<?php echo strtolower(df_proc_output($email1_config)); ?>">
							<span class="help-block">Email Address 1 <span class = "text-error">*</span></span>
						</span>
						<span class = "span6">
							<input type="text" class="validate[custom[email]] span12" name="email2" id="email2" value = "<?php echo strtolower(df_proc_output($email2_config)); ?>">
							<span class="help-block">Email Address 2 (optional)</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Website Details: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required] span12" name="website_name" id="website_name" value = "<?php echo ucwords(df_proc_output($website_name_config)); ?>">
							<span class="help-block">Website Name <span class = "text-error">*</span></span>
						</span>
						<span class = "span6">
							<input type="text" class="validate[required, custom[url]] span12" name="website_url" id="website_url" value = "<?php echo strtolower(df_proc_output($website_url_config)); ?>">
							<span class="help-block">Website URL (ex: http://websitename.com) <span class = "text-error">*</span>
						</span>
					</div>
				</div>
				
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "webconfig_setting_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>
<!-------------------->