<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Change Website Logo</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Change Website Logo</h5>
		<span>Here you can change your website main logo</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/webconfig/do-edit-logo.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<input type = "hidden" name = "old_pic" value = "<?php echo $logo_config; ?>">
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Select Your Website Logo</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>							
				<div class="control-group">
					<label class="control-label">
						Website Main Logo:
						<?php
							if($logo_config != '')
							{
								?>
									<br/>
									<ul class = "list-font">
										<li>
											<i class="fam-photo"></i>
											<a href = "<?php echo $images_preurl; ?>/logo/<?php echo $logo_config; ?>" class = "cust-pad regular lightbox">
												See Current Logo
											</a>
										</li>
									</ul>
								<?php
							}
						?>
					</label>
					<div class="controls">
						<span class = "span6">
							<input type="file" class="validate[custom[imageGeneral]]" name = "pic" id = "pic">
							<span class="help-block">Only .jpg, .jpeg, or .png allowed</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Logo Alternate Text: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt" value = "<?php echo ucwords(df_proc_output($logo_alt_config)); ?>">
						</span>
					</div>
				</div>
				
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "webconfig_logo_submit" value = "Submit">
				</div>
			</div>
		</div>	
	</fieldset>
</form>