<?php	
	$id = df_proc_input($_GET['id']);
	$data = df_general_query_id("hosting_provider", $id);
?>

<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=domain&s_a=hosting">Hosting Provider List</a></li>
		<li class = "active"><a>Edit Provider</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

	<?php
	if($data != false)
	{
		?>		
			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>Edit Provider</h5>
					<span>Here you can edit the hosting provider of the clients domain</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/domain/do-edit-hosting.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<input type = "hidden" name = "id" value = "<?php echo df_proc_output($data['id']); ?>">
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>
							<div class="control-group">
								<label class="control-label">Name: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required, maxSize[100]] span12" name="name" id="name" value = "<?php echo ucwords(df_proc_output($data['name'])); ?>">
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Website URL: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required] span12" name="url" id="url" value = "<?php echo df_proc_output($data['url']); ?>">
									</span>
								</div>
							</div>
							
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "edit_hosting_submit" value = "Submit">
							</div>
						</div>
					</div>
				</fieldset>
			</form>
		<?php
	}	
	else
	{
		?>
		<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>The page is not found</h5>
					<span>Please go back to the <a href = "panel.php?a=domain&s_a=hosting">hosting provider list</a> page.</span>
				</div>
			</div><br/>
		<!-- /page header -->
		<?php
	}
?>