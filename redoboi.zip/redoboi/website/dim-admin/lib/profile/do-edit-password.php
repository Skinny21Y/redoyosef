<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	df_check_user_session();
	if(!isset($_POST['user_password_submit'])) df_make_notification('failed', 'Please fill the details below'); 
	else
	{
		$id = $_SESSION[$dc_user_id];
		$old_password = md5($_POST['old_password']);
		$new_password = md5($_POST['new_password']);
		$conf_password = md5($_POST['conf_password']);
		
		$res = mysql_query("SELECT id FROM user WHERE id = '$id' AND password = '$old_password'");
		if(mysql_num_rows($res) == 1)
		{			
			if($new_password == $conf_password)
			{
				$h_update ="UPDATE user
						   SET password = '$new_password'
						   WHERE id = '$id'";
				mysql_query($h_update);
				$affrow = mysql_affected_rows();
				if ( $affrow == 1 || $affrow==0)
				{	
					df_make_notification('success', 'Your password has been changed successfully');	
				}		
			}
			else 
			{
				df_make_notification('failed', 'Your new password is no confirmed correctly');
			}
		}
		else
		{
			df_make_notification('failed', 'Your old password is incorrect');	
		}
	}
	df_go_to_admin_page('panel.php?a=user-password&t=edit');
?>