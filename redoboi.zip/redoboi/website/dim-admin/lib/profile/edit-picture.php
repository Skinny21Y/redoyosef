<?php	
	$id = $_SESSION[$dc_user_id];
	$data = df_general_query_id("user", $id);
?>

<?php
	if($data != false)
	{
		?>		
			<!-- Breadcrumbs line -->
			<div class="crumbs">
				<ul id="breadcrumbs" class="breadcrumb"> 
					<li class = "active"><a>Change Picture</a></li>
				</ul>
			</div>
			<!-- /breadcrumbs line -->

			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>Change Picture</h5>
					<span>Here you can change your profile picture</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/profile/do-edit-picture.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<input type = "hidden" name = "old_pic" value = "<?php echo $data['pic']; ?>">
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill Your Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>							
							<div class="control-group">
								<label class="control-label">
									Your Picture:
									<?php
										if($data['pic'] != '')
										{
											?>
												<br/>
												<ul class = "list-font">
													<li>
														<i class="fam-photo"></i>
														<a href = "<?php echo $images_preurl; ?>/admin-pic/<?php echo $data['pic']; ?>" class = "cust-pad regular lightbox">
															See Current Picture
														</a>
													</li>
													<li><i class="fam-cross"></i><a href = "lib/profile/do-delete-picture.php" class = "cust-pad delete" onclick = "return confirm('Are you sure you want to remove the current picture?')">Remove Picture</a></li>
												</ul>
											<?php
										}
									?>
								</label>
								<div class="controls">
									<span class = "span6">
										<input type="file" class="validate[custom[imageGeneral]]" name = "pic" id = "pic">
										<span class="help-block">Only .jpg, .jpeg, or .png allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Picture Alternate Text: </label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt" value = "<?php echo ucwords(df_proc_output($data['pic_alt'])); ?>">
									</span>
								</div>
							</div>
							
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "user_picture_submit" value = "Submit">
							</div>
						</div>
					</div>	
				</fieldset>
			</form>
			<!-------------------->
		<?php
	}
?>