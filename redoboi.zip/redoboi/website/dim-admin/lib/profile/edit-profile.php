<?php	
	$id = $_SESSION[$dc_user_id];
	$data = df_general_query_id("user", $id);
?>

<?php
	if($data != false)
	{
		?>		
			<!-- Breadcrumbs line -->
			<div class="crumbs">
				<ul id="breadcrumbs" class="breadcrumb"> 
					<li class = "active"><a>Change Profile</a></li>
				</ul>
			</div>
			<!-- /breadcrumbs line -->

			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>Change Profile</h5>
					<span>Here you can change your profile detail</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/profile/do-edit-profile.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill Your Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>
							<div class="control-group">
								<label class="control-label">Username: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required] span12" name="username" id="username" value = "<?php echo df_proc_output($data['username']); ?>">
										<span class="help-block">Login username</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Email Address: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required, custom[email]] span12" name="email" id="email" value = "<?php echo strtolower(df_proc_output($data['email'])); ?>">
										<span class="help-block">Ex: yourname@youremail</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Additional Info:</label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="span12" name="name" id="name" value = "<?php echo ucwords(df_proc_output($data['name'])); ?>">
										<span class = "help-block">Full Name (ptional)</span>
									</span>
									
									<span class = "span6">
										<input type="text" class="span12" name="phone" id="phone" value = "<?php echo ucwords(df_proc_output($data['phone'])); ?>">
										<span class = "help-block">Phone Number (optional)</span>
									</span>
								</div>
							</div>
							
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "user_profile_submit" value = "Submit">
							</div>
						</div>
					</div>
				</fieldset>
			</form>
			<!-------------------->
		<?php
	}
?>