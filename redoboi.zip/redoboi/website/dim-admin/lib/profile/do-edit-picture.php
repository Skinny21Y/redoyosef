<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(!isset($_POST['user_picture_submit'])) df_make_notification('failed', 'Please fill the details below');
	else
	{
		$id = $_SESSION[$dc_user_id];
		$pic_alt = df_proc_input($_POST['pic_alt']); 
		
		if(df_is_image_exist("pic"))
		{
			$document_name = $_FILES['pic']['name'];
			$document_extension = strtolower(df_get_document_extension($document_name));
			if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png')
			{
				if($pic_alt != '') $pic_temp_name = $pic_alt;
				else $pic_temp_name = $_SESSION[$dc_user_name];
				
				$pic_old_name = df_proc_input($_POST['old_pic']);
				$pic_new_name = df_upload_image("pic", "admin-pic", $pic_temp_name);
				
				
				mysql_query("UPDATE user SET pic = '$pic_new_name', pic_alt = '$pic_alt' WHERE id = '$id'");
				
				$affrow = mysql_affected_rows();
				if($affrow == 1)
				{				
					if($pic_old_name != '') df_delete_image("admin-pic", $pic_old_name);
					df_make_notification('success', 'Your profile picture has been changed successfully');
				}
				else df_make_notification('failed', 'Failed to change your profile picture');
			}
		}	
		else
		{			
			mysql_query("UPDATE user SET pic_alt = '$pic_alt' WHERE id = '$id'");
			$affrow = mysql_affected_rows();
			
			if($affrow == 0 || $affrow == 1)
			{				
				df_make_notification('success', 'Your profile picture alternate text has been changed successfully');
			}
			else df_make_notification('failed', 'Failed to change your profile picture alternate text');
		}
	}
	df_go_to_admin_page('panel.php?a=user-picture&t=edit');
?>