<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	$id=$_SESSION[$dc_user_id];
	$res_pic = mysql_query("SELECT pic FROM user WHERE id = '$id'");
	if(mysql_num_rows($res_pic) == 1)
	{
		$row_pic = mysql_fetch_array($res_pic);
		$pic_name = $row_pic['pic'];
		
		df_delete_image("admin-pic", $pic_name);
		mysql_query("UPDATE user SET pic = '', pic_alt = '' WHERE id = '$id'");
		df_make_notification('success', 'Your profile picture has been removed successfully');
	}
	else df_make_notification('failed', 'Failed to delete your profile picture');
	
	df_go_to_admin_page('panel.php?a=user-picture&t=edit');
?>