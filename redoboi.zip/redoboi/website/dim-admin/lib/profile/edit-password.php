<?php	
	$id = $_SESSION[$dc_user_id];
	$data = df_general_query_id("user", $id);
?>

<?php
	if($data != false)
	{
		?>		
			<!-- Breadcrumbs line -->
			<div class="crumbs">
				<ul id="breadcrumbs" class="breadcrumb"> 
					<li class = "active"><a>Change Password</a></li>
				</ul>
			</div>
			<!-- /breadcrumbs line -->

			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>Change Password</h5>
					<span>Here you can change your password</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/profile/do-edit-password.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill Your Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>							
							<div class="control-group">
								<label class="control-label">Old Password: <span class = "text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="password" class="validate[required, minSize[6]] span12" name="old_password" id="old_password">
										<span class="help-block">Min: 6 characters allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">New Password: <span class = "text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="password" class="validate[required, minSize[6]] span12" name="new_password" id="new_password">
										<span class="help-block">Min: 6 characters allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Confirm New Password: <span class = "text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="password" class="validate[required, equals[new_password], minSize[6]] span12" name="conf_password" id="conf_password">
									</span>
								</div>
							</div>
							
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "user_password_submit" value = "Submit">
							</div>
						</div>
					</div>
				</fieldset>
			</form>
			<!-------------------->
		<?php
	}
?>