<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	df_check_user_session();
	if(!isset($_POST['user_profile_submit'])) df_make_notification('failed', 'Please fill the details below'); 
	else
	{
		$id = $_SESSION[$dc_user_id];
		$username = df_proc_input($_POST['username']);
		$email = strtolower(df_proc_input($_POST['email']));
		$name = df_proc_input($_POST['name']);
		$phone = df_proc_input($_POST['phone']);
		
		$res = mysql_query("SELECT id FROM user WHERE username = '$username' AND id <> '$id'");
		if(mysql_num_rows($res) > 0)
		{
			df_go_to_admin_page('panel.php?a=user-profile&t=edit');
			df_make_notification('failed', "The username $username has been already used");
		}
		else
		{
			$res2 = mysql_query("SELECT id FROM user WHERE email = '$email' AND id <> '$id'");
			if(mysql_num_rows($res2) > 0)
			{
				df_go_to_admin_page('panel.php?a=user-profile&t=edit');
				df_make_notification('failed', "The email $email has been already used by another user");
			}
			
			else
			{
				$q_update = "UPDATE user
							 SET name = '$name', username = '$username', email = '$email', phone = '$phone'
							 WHERE id = '$id'";
				mysql_query($q_update);
				$affrow = mysql_affected_rows();
				if ($affrow == 1 || $affrow == 0)
				{
					$_SESSION[$dc_user_name] = $username;			
					df_make_notification('success', 'Your profile has been changed successfully');	
				}			
			}
		}
	}
	df_go_to_admin_page('panel.php?a=user-profile&t=edit');
?>