<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	if(isset($_POST['forgot_password_submit']))
	{
		$email = df_proc_input($_POST['email']);
		
		$query = "SELECT * FROM user WHERE email = '$email'";
		$res = mysql_query($query);
		if(mysql_num_rows($res) == 1)
		{	
			$row = mysql_fetch_array($res);
			$username = $row['username'];
			$new_password = df_generate_random_string(12);
			$new_formatted_password = md5($new_password);
			
			mysql_query("UPDATE user SET password = '$new_formatted_password' WHERE email = '$email'");
			$affrow = mysql_affected_rows();
			if($affrow == 1)
			{				
				include('do-send-forgot-password.php');
				
				if($is_sent)
				{
					df_make_notification('success', 'Please check your email for the new password');		
					df_go_to_absolute_page('/'.$admin_folder_name.'?ty=2');
				}
				else
				{
					df_make_notification('failed', 'Please try again');		
					df_go_to_absolute_page('/'.$admin_folder_name.'?ty=1');		
				}
			}
			else
			{
				df_make_notification('failed', 'Failed to retrieve your password');		
				df_go_to_absolute_page('/'.$admin_folder_name.'?ty=1');				
			}
		}
		else
		{
			df_make_notification('failed', 'Your email address is not found');		
			df_go_to_absolute_page('/'.$admin_folder_name.'?ty=1');
		}	
	}		
	//df_go_to_absolute_page('/'.$admin_folder_name);
?>