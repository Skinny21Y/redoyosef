<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	if(isset($_POST['login_submit']))
	{
		$username = df_proc_input($_POST['username']);
		$password = md5($_POST['password']);
		
		$query = "SELECT u.id as id, u.username as username, p.privilege as privilege, u.is_active as useractive
				  FROM user u, user_privilege p
				  WHERE u.privilege = p.id AND u.username = '$username' AND u.password = '$password'";
		$res = mysqli_query($connectsql, $query);
		if(mysqli_num_rows($res) == 1)
		{	
			$row = mysqli_fetch_array($res);
			$useractive = $row['useractive'];
			
			if($useractive == 'yes')
			{
				$userid = $row['id'];
				$username = $row['username'];
				$userprivilege = $row['privilege'];
				
				if(isset($_SESSION[$dc_user_id])) unset($_SESSION[$dc_user_id]);
				if(isset($_SESSION[$dc_user_name])) unset($_SESSION[$dc_user_name]);
				if(isset($_SESSION[$dc_user_privilege])) unset($_SESSION[$dc_user_privilege]);
				
				$_SESSION[$dc_user_id] = $userid;
				$_SESSION[$dc_user_name] = $username;
				$_SESSION[$dc_user_privilege] = $userprivilege;
				
				if(df_have_privilege('all') || df_have_privilege('conf')) df_go_to_admin_page('panel.php');
				else if(df_have_privilege('user')) df_go_to_admin_page('panel.php?a=user&s_a=privilege');
				else if(df_have_privilege('dom')) df_go_to_admin_page('panel.php?a=domain&s_a=hosting');
				else
				{
					df_make_notification('failed', 'You do not have any permission to access the administration page');		
					//df_go_to_absolute_page('/'.$admin_folder_name);					
				}
			}
			else 
			{	
				df_make_notification('failed', 'Your account has been suspended');		
				//df_go_to_absolute_page('/'.$admin_folder_name);
			}
		}
		else
		{
			df_make_notification('failed', 'Wrong username or password');		
			//df_go_to_absolute_page('/'.$admin_folder_name);
		}	
	}
?>