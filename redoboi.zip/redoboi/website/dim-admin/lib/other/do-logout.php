<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
	
	if(isset($_SESSION[$dc_user_id]) || $_SESSION[$dc_user_id] != '') unset ($_SESSION[$dc_user_id]);
	if(isset($_SESSION[$dc_user_name]) || $_SESSION[$dc_user_name] != '') unset ($_SESSION[$dc_user_name]);
	if(isset($_SESSION[$dc_user_privilege]) || $_SESSION[$dc_user_privilege] != '') unset($_SESSION[$dc_user_privilege]);
	
	df_go_to_absolute_page('/'.$admin_folder_name);
?>