<?php
	$subject = 'Reset Password at '.ucwords($website_name_config).' website';
	$message_title = 'Reset Password at '.ucwords($website_name_config).' website';
	
	$random_hash = md5(date('r', time()));
	
	$headers = "From: ".$website_name_config." Website <donotreply@".$website_url_config.">";
	if($email2_config != '') $headers .= "\r\nCc: ".$email2_config."";
	$headers .= "\r\nContent-Type: text/html; boundary=\"PHP-alt-".$random_hash."\"";
	
	ob_start();
	
	?>			
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
			"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
			
		<html xmlns="http://www.w3.org/1999/xhtml">
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<title><?php echo ucwords(df_proc_output($website_name_config)); ?></title>
		<style type="text/css"> 
		
			/* Client-specific Styles */
			#outlook a{padding:0;} /* Force Outlook to provide a "view in browser" button. */
			body{width:100% !important;} .ReadMsgBody{width:100%;} .ExternalClass{width:100%;} /* Force Hotmail to display emails at full width */
			body{-webkit-text-size-adjust:none; -ms-text-size-adjust:none;} /* Prevent Webkit and Windows Mobile platforms from changing default font sizes. */

			/* Reset Styles */
			body{margin:0; padding:0; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#333;}
			img{height:auto; line-height:100%; outline:none; text-decoration:none;}
			#backgroundTable{height:100% !important; margin:0; padding:0; width:100% !important;}
			
		   p{font-size: 12px; line-height: 20px; margin-bottom: 0px;}
		   
		   h1, h2, h3, h4, h5, h6 {
			   color: #555 !important;
			   line-height: 100% !important;
		   }
		   
		   h1 a, h2 a, h3 a, h4 a, h5 a, h6 a {
			   color: #1694B9 !important;
		   }
		   
		   h1 a:active, h2 a:active,  h3 a:active, h4 a:active, h5 a:active, h6 a:active {
			   color: #1694B9 !important; /* Preferably not the same color as the normal header link color.  There is limited support for psuedo classes in email clients, this was added just for good measure. */
		   }
		   
		   h1 a:visited, h2 a:visited,  h3 a:visited, h4 a:visited, h5 a:visited, h6 a:visited {
			   color: #1694B9 !important; /* Preferably not the same color as the normal header link color. There is limited support for psuedo classes in email clients, this was added just for good measure. */
		   }
		   
		   
		   table td {
			   border-collapse:collapse;
		   }
		   
		   .yshortcuts, .yshortcuts a, .yshortcuts a:link,.yshortcuts a:visited, .yshortcuts a:hover, .yshortcuts a span { color: black; text-decoration: none !important; border-bottom: none !important; background: none !important;} /* Body text color for the New Yahoo.  This example sets the font of Yahoo's Shortcuts to black. */
		   
		   </style>
		</head>
		
		<body> <!-- Wrapper/Container Table: Use a wrapper table to control the width and the background color consistently of your email. Use this approach instead of setting attributes on the body tag. -->
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td style="padding:10px;">
					
						<table width="100%">
							<tr>
								<td width="100%"><a href="<?php echo $website_url_config;?>" title="" target="_blank">
								<img src="<?php echo $website_url_config;?><?php echo $images_preurl;?>/logo/<?php echo $logo_config; ?>" alt="<?php echo $company_name_config;?>" height="100" style="display:block; margin-bottom:20px;" title="<?php echo $company_name_config;?>" /></a></td>
							</tr>
						</table>
					
						<table cellpadding="0" cellspacing="0" border="0" id="grey-wrap" background="http://dimbleweb.com/ot-img/env-pattern.png" bgcolor="#ededed" style="margin-bottom:10px; background-repeat:repeat-x;" width="100%">
							<tr>
								<td style="padding:25px; padding-top:40px;">
									 <h1 style="color:#1694B9;"><?php echo $message_title; ?></h1>
									
									 <table cellpadding="0" cellspacing="0" border="0" id="white-wrap" bgcolor="#ffffff" style="margin-bottom:10px;" width="100%">
										<tr>
											<td style="padding:15px;">
												
												<p>Hello, <b><?php echo ucwords(df_proc_output($username)); ?></b>. <br/>
												Your password has been resetted successfully. 
												Please use this new password to login to <?php echo ucwords(df_proc_output($website_name_config)); ?> administration panel.</p>
												 
												<p>New Password : <b style = "font-size: 20px;"><?php echo $new_password; ?></b></p><br/>
												<p>Don't forget to change your password later at the administration panel.</p>            
											   
												<p>&nbsp;</p>  
												<p>Best Regards, </p><br/>
												<p><?php echo ucwords(df_proc_output($company_name_config));?></p>
												
											</td>
										</tr>
									</table><!-- #white-wrap -->  
								</td>
							</tr>
						</table>
						
						<div style = "float: right;">
							<p style = "display: block; font-weight: bold; padding-top: 10px; margin-right: 10px; font-size: 11px; text-align: right;">Powered By: </p>
							<p style = "text-align: right; margin-top: 3px;">
								<a href = "http://dimbleweb.com" target = "_blank" title = "Visit Dimbleweb">
									<img src = "http://dimbleweb.com/ot-img/dimbleweb-logo.png" style = "width: 120px; height: 38px;" alt = "Dimbleweb">
								</a>
							</p>
						</div>
					</td>
				</tr>
			</table>
			<!-- End of wrapper table -->
		</body>
		</html>
	<?php	
	$result_message = ob_get_clean();
	$is_sent = @mail($email1_config, $subject, $result_message, $headers);	
?>