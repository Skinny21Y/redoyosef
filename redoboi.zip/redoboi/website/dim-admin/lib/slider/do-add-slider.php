<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('sli'))
	{
		if(!isset($_POST['add_slider_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{
			$title = df_proc_input($_POST['title']); 
			$caption = df_proc_input($_POST['caption']); 
			$link_to = df_proc_input($_POST['link_to']); 
			$is_new_tab = df_proc_input($_POST['is_new_tab']); 
			
			$res_title = mysql_query("SELECT id FROM slider WHERE title = '$title'");
			if(mysql_num_rows($res_title) > 0)
			{
				df_make_notification('failed', "The slideshow titled '$title' has been already used");
				df_go_to_admin_page('panel.php?a=slider&t=add');
			}
			else
			{
				if(df_is_image_exist("pic"))
				{
					$document_name = $_FILES['pic']['name'];
					$document_extension = strtolower(df_get_document_extension($document_name));
					if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png')
					{
						$pic_alt = df_proc_input($_POST['pic_alt']); 
						if($pic_alt != '') $pic_temp_name = $pic_alt;
						else $pic_temp_name = $title;
						
						$pic_new_name = df_upload_image("pic", "slider", $pic_temp_name);
								
						$q_add = "INSERT INTO slider(title, caption, link_to, is_new_tab, pic, pic_alt) 
								  VALUES('$title', '$caption', '$link_to', '$is_new_tab', '$pic_new_name', '$pic_alt')";
						mysql_query($q_add);
						
						$affrow = mysql_affected_rows();
						if($affrow == 1)
						{				
							df_make_notification('success', 'New slideshow has been added successfully');
						}
						else df_make_notification('failed', 'Failed to add new slideshow');
					}
				}	
				else
				{			
					df_make_notification('failed', 'Please select the picture');
					df_go_to_admin_page('panel.php?a=slider&t=add');
				}
			}
		}
	}
	df_go_to_admin_page('panel.php?a=slider');
?>