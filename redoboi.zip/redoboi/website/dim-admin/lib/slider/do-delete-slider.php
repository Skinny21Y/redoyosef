<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('sli'))
	{	
		$id = df_proc_input($_GET['id']);
		
		$res = mysql_query("SELECT pic FROM slider WHERE id = '$id'");
		if(mysql_num_rows($res) > 0) 
		{
			$row = mysql_fetch_array($res); 
			$image_name = $row['pic'];
			if($image_name != '') df_delete_image('slider', $image_name);
		}
		
		$q_update = "DELETE FROM slider WHERE id = '$id'";
		mysql_query($q_update);
		$affrow = mysql_affected_rows();
		if($affrow == 1) df_make_notification("success", "The selected slideshow has been deleted successfully");
		else df_make_notification("failed", "Failed to delete the selected slideshow");
		
		if(strpos($_SESSION[$page_session_key], "a=slider") !== false) df_go_to_absolute_page($_SESSION[$page_session_key]);
		else df_go_to_admin_page('panel.php?a=slider');
	}	
	else df_go_to_admin_page('panel.php');
?>