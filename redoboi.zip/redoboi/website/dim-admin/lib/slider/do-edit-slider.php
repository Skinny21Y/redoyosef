<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('sli'))
	{
		if(!isset($_POST['edit_slider_submit'])) df_make_notification('failed', 'Please fill the details below');
		else
		{		
			$id = df_proc_input($_POST['id']);			
			$title = df_proc_input($_POST['title']); 
			$caption = df_proc_input($_POST['caption']); 
			$link_to = df_proc_input($_POST['link_to']); 
			$is_new_tab = df_proc_input($_POST['is_new_tab']); 
			$pic_alt = df_proc_input($_POST['pic_alt']); 
			
			$res_title = mysql_query("SELECT id FROM slider WHERE title = '$title' AND id <> '$id'");
			if(mysql_num_rows($res_title) > 0)
			{
				df_make_notification('failed', "The slideshow titled '$title' has been already used");
				df_go_to_admin_page('panel.php?a=slider&t=edit&id='.$id);
			}
			else
			{
				$q_update = "UPDATE slider SET title = '$title', caption = '$caption', link_to = '$link_to', is_new_tab = '$is_new_tab', pic_alt = '$pic_alt' WHERE id = '$id'";
				mysql_query($q_update);
				
				$affrow = 0;
				$affrow = mysql_affected_rows();
				
				if(df_is_image_exist("pic"))
				{
					$document_name = $_FILES['pic']['name'];
					$document_extension = strtolower(df_get_document_extension($document_name));
					if($document_extension == 'jpeg' || $document_extension == 'jpg' || $document_extension == 'png')
					{
						if($pic_alt != '') $pic_temp_name = $pic_alt;
						else $pic_temp_name = $title;
						
						$pic_old_name = df_proc_input($_POST['old_pic']);
						$pic_new_name = df_upload_image("pic", "slider", $pic_temp_name);					
						
						mysql_query("UPDATE slider SET pic = '$pic_new_name' WHERE id = '$id'");
						
						$affrow2 = mysql_affected_rows();
						if($affrow2 == 1)
						{				
							if($pic_old_name != '') df_delete_image("slider", $pic_old_name);
						}
					}
				}	
				if($affrow == 0 || $affrow == 1) df_make_notification('success', 'The selected slideshow has been updated successfully');
			}
		}
	}
	df_go_to_admin_page('panel.php?a=slider');
?>