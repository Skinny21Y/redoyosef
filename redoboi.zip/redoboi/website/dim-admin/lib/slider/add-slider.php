<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=slider">Slideshow List</a></li>
		<li class = "active"><a>Add New Slideshow</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Add New Slideshow</h5>
		<span>Here you can add a new slideshow for your website home page</span>
	</div>
</div><br/>
<!-- /page header -->

<!-- Widget Content -->
<form id="validate" class="form-horizontal" action="lib/slider/do-add-slider.php" method = "post" enctype = "multipart/form-data">
	<fieldset>
		<!-- Form validation -->
		<div class="widget">
			<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
			<div class="well row-fluid">	
				<?php df_update_notification(); ?>
				<div class="control-group">
					<label class="control-label">Title: <span class="text-error">*</span></label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[required, maxSize[25]] span12" name="title" id="title">
							<span class="help-block">Max: 25 characters allowed</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Caption (optional):</label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[maxSize[100]] span12" name="caption" id="caption">
							<span class="help-block">Max: 100 characters allowed</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Link to (optional):</label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[custom[url]] span12" name="link_to" id="link_to">
							<span class="help-block">Ex: http://websitename.com</span>
						</span>
					</div>
				</div>
								
				<div class="control-group">
					<label class="control-label">Link Clicked (optional):</label>
					<div class="controls">
						<span class = "span6">	
							<label class="radio inline">
								<input type="radio" id="status_y" class="styled" value="yes" name = "is_new_tab" checked>
								Open in new tab
							</label>
							<label class="radio inline">
								<input type="radio" id="status_n" class="styled" value="no" name = "is_new_tab">
								Open in same tab
							</label>
						</span>		
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">
						Picture: <span class = "text-error">*</span>
					</label>
					<div class="controls">
						<span class = "span6">
							<input type="file" class="validate[required, custom[imageGeneral]]" name = "pic" id = "pic">
							<span class="help-block">Size: 960px &times; 420px (Only .jpg, .jpeg, or .png allowed)</span>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">Picture Alternate Text: </label>
					<div class="controls">
						<span class = "span6">
							<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt">
						</span>
					</div>
				</div>
												
				<div class="form-actions align-right">
					<input type="reset" class="btn" value = "Reset">
					<input type="submit" class="btn btn-info" name = "add_slider_submit" value = "Submit">
				</div>
			</div>
		</div>
	</fieldset>
</form>