<?php
	session_start();
	include ("../../include/connection.php");
	include ("../../include/config.php");
	include ("../../include/function.php");
		
	df_check_user_session();
	
	if(df_have_privilege('all') || df_have_privilege('sli'))
	{
		$totalrow = 0;
		for ($i = 0; $i < count($_POST['slider_list']); $i++)
		{
			$id = $_POST['slider_list'][$i];
			
			$res = mysql_query("SELECT * FROM slider WHERE id = '$id'");
			if(mysql_num_rows($res) == 1)
			{
				$row = mysql_fetch_array($res);
				$pic = $row['pic'];
				
				$q_delete = "DELETE FROM slider WHERE id = '$id'";
				mysql_query($q_delete);
				if($pic != '') df_delete_image('slider', $pic);
				
				$affrow = mysql_affected_rows();
				$totalrow = $totalrow + $affrow;
			}
		}  
		
		if($totalrow > 0) 
		{
			if($totalrow == 1) df_make_notification("success", "1 slideshow has been deleted successfully");
			else df_make_notification("success", "$totalrow slideshows have been deleted successfully");
		}
		else df_make_notification("failed", "Failed to delete the selected slideshows");
		df_go_to_admin_page('panel.php?a=slider');
	}
	
	df_go_to_admin_page('panel.php?a=slider');
?>