<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li class = "active"><a>Slideshow List</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

<!-- Page header -->
<div class="page-header">
	<div class="page-title">
		<h5>Slideshow List</h5>
		<span>Here you can see the list of slideshow displayed at your website home page</span>
	</div>
</div><br/>
<!-- /page header -->

<?php	
	/* PAGING VARIABLE */
	$item_num = 10;
	$path = 'panel.php?a=slider';	
	$q_main_display = "SELECT * FROM slider ORDER BY id ASC";
	
	$max_displayed_page = 10;
	$start_index = ($pagenum - 1) * $item_num;
	
	$q_current_display = $q_main_display." LIMIT $start_index, $item_num";
	$result = mysql_query($q_current_display);
	
	/* FOR PAGE URL SESSION */	
	if(!isset($_SESSION[$page_session_key])) $_SESSION[$page_session_key] = '';
	$_SESSION[$page_session_key] = $_SERVER['REQUEST_URI'];
?>

<!-- BULKACTION FUNCTION -->
<script type = "text/javascript">
function bulkaction_check()
{
	var is_check = document.getElementById("masterCheck").checked;
	var bulked = document.forms['bulkaction-form']['slider_list[]'];
	
	if(is_check)
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = true;
	}
	else
	{
		for (var i = 0; i < bulked.length; i++) bulked[i].checked = false;		
	}
}
</script>
<!------------------------->
              
<!-- Table with footer -->
<form action = "lib/slider/do-bulkaction-slider.php" id = "bulkaction-form" name = "bulkaction-form" method = "post" enctype = "multipart/form-data" onsubmit = "return confirm('Are you sure?')">
<div class="widget">
	<div class="navbar">
		<div class="navbar-inner">
			<h6>Slideshow List</h6>
			<div class="nav pull-right">
				<a href="#" class="dropdown-toggle navbar-icon" data-toggle="dropdown"><i class="icon-cog"></i></a>
				<ul class="dropdown-menu pull-right">
					<li><a href="panel.php?a=slider&t=add"><i class="icon-plus"></i>Add New Slider</a></li>
				</ul>
			</div>
		</div>
	</div>
	
	<?php df_update_notification(); ?>
	<div class="table-overflow">
		<table class="table table-bordered table-striped table-checks">
			<thead>
				<tr>
					<th style = "width: 2%;"><input type="checkbox" name="checkRow" id = "masterCheck" onclick = "bulkaction_check()"/></th>
					<th style = "width: 5%;">No</th>
					<th style = "width: 15%;">Picture</th>
					<th style = "width: 15%;">Title</th>
					<th style = "width: 25%;">Caption</th>					
					<th style = "width: 25%;">Link To</th>			
					<th style = "width: 15%;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php					
					if (mysql_num_rows($result) > 0 )
					{
						$no= $start_index;
						while($row = mysql_fetch_array($result))
						{
							$no++;
							?>
								<tr>
									<td><input type="checkbox" name="slider_list[]" value = "<?php echo df_proc_output($row['id']); ?>"/></td>
									<td><?php echo $no; ?></td>
									<td>
										<?php
											if($row['pic'] != '') 
											{ 
												?> 
													<a href = "<?php echo $images_preurl; ?>/slider/<?php echo $row['pic']; ?>" class = "lightbox">
														<img src = "<?php echo $images_preurl; ?>/slider/<?php echo $row['pic']; ?>">
													</a>
												<?php
											}
										?>
									</td>
									<td><?php echo ucwords(df_proc_output($row['title'])); ?></td>
									<td><?php echo ucfirst(df_proc_output($row['caption'])); ?></td>
									<td>
										<?php
											if($row['link_to'] == '') echo '---';
											else
											{
												?>
													<i class = "fam-world-link"></i><a href = "<?php echo $row['link_to']; ?>" target = "_blank" title = "Visit this link">&nbsp;<?php echo $row['link_to']; ?></a>
													<br/>Opened in <b><?php if($row['is_new_tab'] == 'yes') echo '<span class = "label label-success">New Tab</span>'; else echo '<span class = "label label-info">Same Tab</span>'; ?></b>
												<?php
											}
										?>
									</td>
									<td>
										<ul class="table-controls">
											<li><a href="panel.php?a=slider&t=edit&id=<?php echo $row['id']; ?>" class="tip" title="Edit Slider"><i class="fam-pencil"></i></a> </li>
											<li><a href="lib/slider/do-delete-slider.php?id=<?php echo $row['id']; ?>" class="tip" title="Delete Slider" onclick = "return confirm('Are you sure you want to delete this slider?')"><i class="fam-cross"></i></a> </li>
										</ul>
									</td>
								</tr>
							<?php
						}
					}
					else 
					{
						?>
							<tr>
								<td colspan = "7" align = "center"><b><i>NO RECORDS FOUND</i></b></td>
							</tr>
						<?php
					}
				?>
			</tbody>
			
			<?php
				if(mysql_num_rows($result) > 0)
				{
					$start_num = $start_index + 1;
					$fin_num = $start_index + mysql_num_rows($result);
					$res_tot = mysql_query($q_main_display);
					$tot_num = mysql_num_rows($res_tot);
					?>
						<tfoot>
							<tr>
								<td colspan = "7" align = "center">Showing <b><?php echo $start_num; ?> to <?php echo $fin_num; ?></b> of <b><?php echo $tot_num; ?></b> record(s)</td>
							</tr>
						</tfoot>
					<?php
				}
			?>
		</table>
	</div>
	
	<?php 
		if(mysql_num_rows($result) > 0) 
		{
			?>
				<div class="table-footer">
					<div class="table-actions">
						<label>Apply action:</label>
						<select class="styled">
							<option value="">Select action...</option>
							<option value="Delete">Delete Selected Slideshows</option>
						</select>
						&nbsp;&nbsp;<input type = "submit" class="btn btn-info" value = "Submit">
					</div>
					<?php df_pagination($pagenum, $item_num, $max_displayed_page, $q_main_display, $path); ?>
				</div>
			<?php
		}
	?>
</div>
</form>
<!-- /table with footer -->