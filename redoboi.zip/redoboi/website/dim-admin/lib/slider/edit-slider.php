<?php	
	$id = df_proc_input($_GET['id']);
	$data = df_general_query_id("slider", $id);
?>

<!-- Breadcrumbs line -->
<div class="crumbs">
	<ul id="breadcrumbs" class="breadcrumb"> 
		<li><a href = "panel.php?a=slider">Slideshow List</a></li>
		<li class = "active"><a>Edit Slideshow</a></li>
	</ul>
</div>
<!-- /breadcrumbs line -->

	<?php
	if($data != false)
	{
		?>		
			<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>Edit Slideshow</h5>
					<span>Here you can edit the slideshow displayed at your website home page</span>
				</div>
			</div><br/>
			<!-- /page header -->

			<!-- Widget Content -->
			<form id="validate" class="form-horizontal" action="lib/slider/do-edit-slider.php" method = "post" enctype = "multipart/form-data">
				<fieldset>
					<input type = "hidden" name = "id" value = "<?php echo df_proc_output($data['id']); ?>">
					<input type = "hidden" name = "old_pic" value = "<?php echo df_proc_output($data['pic']); ?>">
					<!-- Form validation -->
					<div class="widget">
						<div class="navbar"><div class="navbar-inner"><h6>Please Fill The Details</h6></div></div>
						<div class="well row-fluid">	
							<?php df_update_notification(); ?>
							<div class="control-group">
								<label class="control-label">Title: <span class="text-error">*</span></label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[required, maxSize[25]] span12" name="title" id="title" value = "<?php echo ucwords(df_proc_output($data['title'])); ?>">
										<span class="help-block">Max: 25 characters allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Caption (optional):</label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[maxSize[100]] span12" name="caption" id="caption" value = "<?php echo ucfirst(df_proc_output($data['caption'])); ?>">
										<span class="help-block">Max: 100 characters allowed</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Link to (optional):</label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[custom[url]] span12" name="link_to" id="link_to" value = "<?php echo df_proc_output($data['link_to']); ?>">
										<span class="help-block">Ex: http://websitename.com</span>
									</span>
								</div>
							</div>
											
							<div class="control-group">
								<label class="control-label">Link Clicked (optional):</label>
								<div class="controls">
									<span class = "span6">	
										<label class="radio inline">
											<input type="radio" id="status_y" class="styled" value="yes" name = "is_new_tab" <?php if($data['is_new_tab'] == 'yes') echo 'checked'; ?>>
											Open in new tab
										</label>
										<label class="radio inline">
											<input type="radio" id="status_n" class="styled" value="no" name = "is_new_tab" <?php if($data['is_new_tab'] == 'no') echo 'checked'; ?>>
											Open in same tab
										</label>
									</span>		
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">
									Picture: 
									<?php
										if($data['pic'] != '')
										{
											?>
												<br/>
												<ul class = "list-font">
													<li>
														<i class="fam-photo"></i>
														<a href = "<?php echo $images_preurl; ?>/slider/<?php echo $data['pic']; ?>" class = "cust-pad regular lightbox">
															See Current Slideshow
														</a>
													</li>
												</ul>
											<?php
										}
									?>
								</label>
								<div class="controls">
									<span class = "span6">
										<input type="file" class="validate[custom[imageGeneral]]" name = "pic" id = "pic">
										<span class="help-block">Size: 960px &times; 420px (Only .jpg, .jpeg, or .png allowed)</span>
									</span>
								</div>
							</div>
							
							<div class="control-group">
								<label class="control-label">Picture Alternate Text: </label>
								<div class="controls">
									<span class = "span6">
										<input type="text" class="validate[maxSize[150]] span12" name="pic_alt" id="pic_alt" value = "<?php echo ucwords(df_proc_output($data['pic_alt'])); ?>">
									</span>
								</div>
							</div>
															
							<div class="form-actions align-right">
								<input type="reset" class="btn" value = "Reset">
								<input type="submit" class="btn btn-info" name = "edit_slider_submit" value = "Submit">
							</div>
						</div>
					</div>
				</fieldset>
			</form>
		<?php
	}	
	else
	{
		?>
		<!-- Page header -->
			<div class="page-header">
				<div class="page-title">
					<h5>The page is not found</h5>
					<span>Please go back to the <a href = "panel.php?a=user&s_a=user">users list</a> page.</span>
				</div>
			</div><br/>
		<!-- /page header -->
		<?php
	}
?>