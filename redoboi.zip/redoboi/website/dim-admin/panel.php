<?php include ("header.php"); ?>
<body>
	<?php include ("top.php"); ?>
	
	<!-- Content container -->
	<div id="container">

		<?php include ("sidebar.php"); ?>

		<!-- Content -->
		<div id="content">

		    <!-- Content wrapper -->
		    <div class="wrapper">				
				<?php include ("content.php"); ?>
		    </div>
		    <!-- /content wrapper -->

		</div>
		<!-- /content -->

	</div>
	<!-- /content container -->


<?php include ("footer.php"); ?>
