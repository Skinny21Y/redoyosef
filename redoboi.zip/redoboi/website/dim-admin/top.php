<!-- Fixed top -->
<div id="top">
	<div class="fixed">
		<h2 class = "top-nav-title"><?php echo ucwords(df_proc_output($website_name_config)); ?> Administration Page</h2>
		<ul class="top-menu">
			<li><a class = "fullview"></a></li>
			<li class="dropdown">
				<a class="user-menu" data-toggle="dropdown">
					<?php
						$admin_pic = df_single_query_id_based('user', 'pic', $_SESSION[$dc_user_id]);
						$admin_pic_alt = df_single_query_id_based('user', 'pic_alt', $_SESSION[$dc_user_id]);
						
						if($admin_pic != '') { ?> <img src="<?php echo $images_preurl; ?>/admin-pic/<?php echo $admin_pic; ?>" alt="<?php echo ucwords(df_proc_output($admin_pic_alt)); ?>" title="<?php echo ucwords(df_proc_output($admin_pic_alt)); ?>"/> <?php }
						else { ?> <img src = "<?php echo $images_preurl; ?>/default/no-photo.jpg" title="<?php echo ucwords(df_proc_output($admin_pic_alt)); ?>" alt="<?php echo ucwords(df_proc_output($admin_pic_alt)); ?>"> <?php }
					?>
					<span>Howdy, <?php echo ucwords(df_proc_output($_SESSION[$dc_user_name])); ?>! <b class="caret"></b></span>
				</a>
				<ul class="dropdown-menu">
					<li><a href="panel.php?a=user-profile&t=edit" title=""><i class="icon-user"></i>Change Profile</a></li>
					<li><a href="panel.php?a=user-password&t=edit" title=""><i class="icon-lock"></i>Change Password</a></li>
					<li><a href="panel.php?a=user-picture&t=edit" title=""><i class="icon-camera-retro"></i>Change Picture</a></li>
					<li><a href="<?php echo $admin_preurl; ?>/lib/other/do-logout.php" onclick = "return confirm('Are you sure you want to logout?')"><i class="icon-off"></i>Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
</div>
<!-- /fixed top -->