-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2020 at 10:33 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `redoboi`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_list`
--

DROP TABLE IF EXISTS `account_list`;
CREATE TABLE `account_list` (
  `id` int(11) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `username_pages_email` varchar(200) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `client_domain`
--

DROP TABLE IF EXISTS `client_domain`;
CREATE TABLE `client_domain` (
  `id` int(5) NOT NULL,
  `hosting_provider_id` int(5) NOT NULL,
  `name` varchar(120) NOT NULL,
  `person_name` varchar(120) NOT NULL,
  `person_phone` varchar(30) NOT NULL,
  `website_url` varchar(220) NOT NULL,
  `cp_url` varchar(220) NOT NULL,
  `cp_username` varchar(120) NOT NULL,
  `cp_password` varchar(120) NOT NULL,
  `domain_start_date` date NOT NULL,
  `domain_exp_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_domain`
--

INSERT INTO `client_domain` (`id`, `hosting_provider_id`, `name`, `person_name`, `person_phone`, `website_url`, `cp_url`, `cp_username`, `cp_password`, `domain_start_date`, `domain_exp_date`) VALUES
(1, 6, 'Dimbleweb', 'Adi Halim', '085890812211', 'http://dimbleweb.com', 'http://dimbleweb.com/cpanel', 'h118076', 'dimcpanel8228', '2013-06-30', '2016-07-06'),
(2, 6, 'Eilene Cherie', 'Windy', '081908819560', 'http://eilenecherie.com', 'http://eilenecherie.com/cpanel', 'h118077', 'U14svenZ29', '2014-07-07', '2015-07-23'),
(3, 8, 'Gambreng Games', 'Riris Marpaung', '', 'http://gambrenggames.com', 'http://gambrenggames.com/cpanel', 'gambreng', 'd0d1ckr1r1sb0n4r', '2013-07-02', '2015-07-02'),
(4, 6, 'Dimblehosting', 'Adi Halim', '085890812211', 'http://dimblehosting.com', 'http://dimblehosting.com/cpanel', 'h115284', 'as0yz65Mh2', '2013-09-14', '2014-09-14'),
(5, 5, 'Koin Media', 'Sarah', '085710391297', 'http://koin-media.com', 'http://koin-media.com/cpanel', 'koit1253', 'mZ1y1vmPC0bl', '2013-07-29', '2015-07-29'),
(6, 4, 'Wijaya Power System', 'Windy', '081908819560', 'http://wijayapowersystem.com', 'http://wijayapowersystem.com/cpanel', 'wijayapo', 'fmlaR4Z2Hd(u', '2012-10-24', '2015-10-24'),
(7, 0, 'PT Databaseku Solutindo', 'Shandery', '0817220111', 'http://databaseku.com', 'http://databaseku.com/cpanel', 'k4583044', 'Hosea6.3', '2012-05-08', '2015-05-08'),
(8, 6, 'Cloud SLA', 'Charles Lim', '087780800558', 'http://cloudsla.org', 'http://cloudsla.org/cpanel', 'h115663', '@F7bhN&O+8Cv', '0000-00-00', '0000-00-00'),
(9, 5, 'Benang Online', 'Iwan', '089635999137', 'http://benangonline.com', 'http://benangonline.com/cpanel', 'benan440', 'abcd1234@1234', '2013-05-03', '2015-05-03'),
(10, 6, 'Uniview Indonesia', 'Go Peter Perwira', '081578156789', 'http://uniview-indonesia.com', 'http://uniview-indonesia.com/cpanel', 'h115977', '9q27m1lBcQ', '2013-11-21', '2014-11-21'),
(11, 6, 'Pohipo', 'Andrew Hutama', '081310282986', 'http://pohipo.com', 'http://pohipo.com/cpanel', 'h116283', 'hutama1990203313chandra', '2013-12-24', '2014-12-24'),
(12, 6, 'Olshe Home', 'Adrienne Olivia', '', 'http://olshehome.com', 'http://olshehome.com/cpanel', 'h116801', 'B4md8Q33te', '2014-02-18', '2015-02-18'),
(13, 6, 'PT Bias Promosindo', 'Go Peter Perwira', '081578156789', 'http://bias.co.id', 'http://bias.co.id/cpanel', 'h117058', 'bias123!@#', '2014-03-25', '2016-03-24'),
(14, 0, 'PT Olah Makan Indonesia', 'Andriadi Winaga', '08170080199', 'http://olahmakanindonesia.com', 'http://olahmakanindonesia.com/cpanel', 'olahmak1', 'Phigu9pu', '2013-09-16', '2015-09-16'),
(15, 6, 'PT Lenny Promo Indo Jaya', 'Lenny', '08128707068', 'http://lennypromoindojaya.com', 'http://lennypromoindojaya.com/cpanel', 'h118415', 'yU2k68cCz2', '2014-09-01', '2015-09-01'),
(16, 6, 'Soya Bean Graphic House', 'Windy Huang', '081908819560', 'http://soyabeangraphic.com', 'http://soyabeangraphic.com/cpanel', 'soyabean', 'dv1XhK014l', '2014-10-18', '2018-10-18'),
(17, 6, 'Bebas Thalassemia', 'Andrew Hutama', '08118457333', 'http://bebas-thalassemia.com', 'http://bebas-thalassemia.com/cpanel', 'h119176', 'Hl6r50eT2q', '2014-11-02', '2015-11-02'),
(18, 9, 'Dimbleinc', 'Adi Halim', '+6285890812211', 'http://dimbleinc.com', 'http://dimbleinc.com/cpanel', 'jasabuat', 'dimcpanel8228!@#', '2014-09-29', '2015-09-29'),
(19, 6, 'Glow For Indonesia', 'Gloria Marcella', '+62 22 2032655', 'http://glowforindonesia.org', 'http://glowforindonesia.org/cpanel', 'glowfori', 'd69ctP1sX4', '2014-12-07', '2015-12-07'),
(20, 6, 'Sinar Agung Travel', 'Satrio', '081510129339', 'http://sinaragungtravel.com', 'http://sinaragungtravel.com/cpanel', 'sinaragu', 'A014wrtZj8', '2015-02-13', '2016-02-13'),
(21, 5, 'Packaholiq', 'Victor Ideabox', 'BB: 7F44C0FF', 'http://packaholiq.com', 'http://packaholiq.com/cpanel', 'pacq2849', 'uDpe5hPiNndS77', '2015-02-16', '2015-10-08'),
(22, 10, 'Korean Hair Clip', 'Ricky Salim', '', 'http://koreanhairclip.com', 'https://securesgp22.sgcpanel.com:2083/logout/?locale=%3Ccpanel%20print=', 'rickzz89', 'srFeXq_MG<T.vhscA', '0000-00-00', '0000-00-00'),
(23, 6, 'Jual Running Text', 'Go Peter Perwira', '081578156789', 'http://jualrunningtext.co.id', 'http://jualrunningtext.co.id/cpanel', 'jualrunn', 'r9YW61ne8w', '2015-06-11', '2016-06-10'),
(24, 6, 'Merah Marunten', 'Christian Suherman', '085694016662', 'http://merahmarunten.com', 'http://merahmarunten.com/cpanel', 'merahmar', '1JLdg43l8u', '2015-06-16', '2016-06-16'),
(25, 11, 'PT Indo Sinar Jaya', 'Triden Tan', '+62 856 6832 6233', 'http://indosinarjaya.com', 'http://indosinarjaya.com/cpanel', 'indosina', '1Dg698wWpd', '2015-06-11', '2016-06-11'),
(26, 11, 'PT Indoserena', 'Triden Tan', '+62 856 6832 6233', 'http://indoserena.com', 'http://indoserena.com/cpanel', 'indosere', 'Dwim4kmur888', '2013-07-16', '2016-07-16'),
(27, 0, 'MKBTM', 'Triden Tan', '+62 856 6832 6233', 'http://mkbtm.com', 'http://mkbtm.com/cpanel', 'mkbtmcom', '9d9s1F4Tgn', '2015-07-14', '2016-07-14'),
(28, 0, 'Triden Works', 'Triden Tan', '+62 856 6832 6233', 'http://tridenworks.com', 'http://tridenworks.com/cpanel', 'tridenwo', 'cux938Xo9R', '2015-07-15', '2016-07-15'),
(29, 10, 'Mer C Perfume', 'Ricky Salim', '', 'http://mercperfume.com', 'https://gator625.hostgator.com:2083', 'rickzz89', 'jasawordpress', '0000-00-00', '0000-00-00'),
(30, 5, 'PT Kibar Karya Sukses', 'Thian Lionel', '081905058168', 'http://kibarks.com', 'http://kibarks.com/cpanel', 'kibar326', 'kibarks1235', '2013-06-14', '2016-06-14'),
(31, 6, 'Metrocon Group', 'Go Peter Perwira', '081578156789', 'http://metrocongroup.com', 'http://metrocongroup.com/cpanel', 'metrocon', '2z4tsQ48Bq', '2015-09-07', '2016-09-07'),
(32, 6, 'GPDI Hebron', 'Christian Suherman', '085694016662', 'http://gpdi-hebron.com', 'http://gpdi-hebron.com/cpanel', '(on dimbleinc)', '(on dimbleinc)', '2015-10-05', '2017-10-05'),
(33, 10, 'Bahasa Mandarin Center', 'Yendy', '081311338832', 'http://bahasamandarincenter.com', 'http://bahasamandarincenter.com/cpanel', 'yendy', 'oaayvYWbJnTb', '2011-06-30', '2016-06-30'),
(34, 6, 'KAP Hadori', 'Adi Halim', '085890812211', 'http://hlbjktdua.com', 'http://hlbjktdua.com/cpanel', 'hlbjktdu', 'Jamesjansen09', '2015-10-22', '2016-10-22'),
(35, 0, 'Arebi Banten', 'Triden', '+6285668326233', 'http://arebibanten.com', 'http://arebibanten.com/cpanel', 'arebiban', 'wE491l9tRx', '2015-01-20', '2020-01-20'),
(36, 11, 'Serpong Jaya', 'Triden', '+6285668326233', 'http://serpongjaya.com', 'http://serpongjaya.com/cpanel', 'ser10001', 'ser48254', '2015-09-19', '2016-09-19'),
(37, 11, 'Hawaii Bali', 'Windy', '081908819560', 'http://hawaiibali.com', 'http://hawaiibali.com/cpanel', 'hawaiiba', 'K6P1t41szs', '2015-11-23', '2016-11-23'),
(38, 11, 'Jaya Imperial Park', 'Triden', '085668326233', 'http://jayaimperialpark.com', 'http://jayaimperialpark.com/cpanel', 'jayakcom', 'jay50977', '2014-05-06', '2016-05-06'),
(39, 11, 'Grand Batavia', 'Triden', '085668326233', 'http://grandbataviajaya.com', 'http://grandbataviajaya.com/cpanel', 'grandbat', 'w0L55a7faX', '2014-12-22', '2015-12-22'),
(40, 11, '10NZ Website', 'Triden', '085668326233', 'http://10nzplace.com', '10nzplace.com/cpanel', 'nzplacec', 'ucwWzdZfVl^u', '2015-11-02', '2016-11-02'),
(41, 12, 'KAP Hadori (Ver 2)', 'Adi Halim', '085890812211', 'http://hlbjktdua.com', 'http://hlbjktdua.com/cpanel', 'hlbjktdu', 'Jamesjansen09', '2015-11-30', '2016-11-30'),
(42, 11, 'Jual Beli Hotel', 'Triden', '085668326233', 'http://jualbelihotel.com', 'http://jualbelihotel.com/cpanel', 'jualbel2', '0dfb28J9Yw', '2015-10-14', '2016-10-14'),
(43, 0, 'Ibu Ayu', 'Ibu Ayu', '081210750709', 'http://natzricebox.com', 'http://natzricebox.com/cpanel', 'krkkacfy', 'd9mrS99T1e', '0000-00-00', '0000-00-00'),
(44, 11, 'Lumina City', 'Triden', '085668326233', 'http://luminacity.co.id', 'luminacity.co.id:2082', 'luminaci', 'Mm61zyr89J', '2016-04-08', '2017-04-08'),
(45, 11, 'Zfix', 'Jeremia', '082111940047', 'http://zfix.co.id', 'http://zfix.co.id/cpanel', 'zfixcoid', '1IA8d23uhv', '2016-04-26', '2017-04-26'),
(46, 11, 'Zfix 2', 'Jeremia', '082111940047', 'http://ifixnstore.id/', 'http://ifixnstore.id/cpanel', 'ifixnsto', 'vkCmo818U1', '2016-05-10', '2017-05-10'),
(47, 5, 'ICB Garment', 'Windy', '081908819560', 'http://icbgarment.com/', 'http://icbgarment.com/cpanel', 'icbs2124', 'pindahSoya16', '2016-06-03', '2017-06-03'),
(48, 12, 'Get 500%', 'Bu Hindri', '081284250558', 'http://wow500persen.com', 'http://wow500persen.com/cpanel', 'u5923468', 'wow500ABC123', '2016-06-28', '2017-06-27'),
(49, 11, 'Emerald Bintaro', 'Triden', '081243800985', 'http://emeraldbintaro.com', 'https://119.235.255.133:10000', 'admin', 'EmeraldBin@2016', '2015-05-20', '2017-05-20'),
(50, 0, 'Daniel', 'Daniel', '081281389164', 'http://manage.kilathosting.com', 'http://manage.kilathosting.com', 'allcosta', 'Kr@t61v0', '0000-00-00', '0000-00-00'),
(51, 5, 'The House Studio', 'Triden', '081243800985', 'http://thehouse.studio', 'http://thehouse.studio/cpanel', 'thehouse', 'q583lXs9Rx', '2016-07-20', '2017-07-20'),
(53, 13, 'Manage Kilat Hosting 1', 'Daniel DNArtworks', '081281389164', 'http://manage.kilathosting.com', 'http://manage.kilathosting.com', 'primecon', '86g7IcR8au', '2016-10-06', '2017-10-06'),
(54, 0, 'IPrivate Hire', 'Sanny Iprivate', '+6287889092828', 'http://iprivatehire.co.uk/', 'https://lhcp1036.webapps.net:2083/', 'ta1vrjcn', 'iprivatehire!@#456', '2016-11-01', '2017-08-10'),
(55, 14, 'Veris', 'Daniel', '+62 812 8138 9164', 'http://veris-consulting.com', 'http://godaddy.com', '36706944', 'Vood00child', '2016-11-29', '2017-06-07'),
(56, 7, 'GSRI Kartini', 'Sanny Tjandradjaja', '0818977589', 'http://gsrikartini.org', 'http://gsrikartini.org/cpanel', 'k5072537', '33Ox0nQf8i', '2016-09-06', '2017-09-06'),
(57, 12, 'The House Studio 2', 'Triden', '081243800985', 'http://thehouse.studio', 'http://thehouse.studio/cpanel', 'u0437315', 'asdf!@#456', '2016-07-20', '2017-07-20'),
(58, 0, 'PT Perkindo', 'Miko', '+6281317471537â€‹â â€‹', 'http://ptperkindo.com', 'http://ptperkindo.com/cpanel', 'ptperkin', 'zxcvbn1024', '2009-09-28', '2017-09-28'),
(59, 11, 'Framework UPVC', 'William', '087880233811', 'http://frameworkupvc.com', 'http://frameworkupvc.com/cpanel', 'framewor', '1RSco9i2n4', '2017-04-19', '2018-04-19'),
(60, 15, 'Yasmin Hotel', 'Satrio', '081510129399', 'http://yasminhotels.com', 'http://yasminhotels.com/cpanel', 'yasminhotels', '20hotels15', '2013-04-05', '2019-04-05'),
(61, 0, 'Metamorphosys', 'Triden', '081243800985', 'http://metamorphosys.co.id', 'http://metamorphosys.co.id:2082/', 'u0437315', 'ZzFh8FnffX5ubwca', '2017-08-30', '2018-08-30'),
(62, 16, 'Loxiaphoto', 'Aditya', '08192202020', 'http://loxiaphoto.com', 'http://loxiaphoto.com/cpanel', 'loxia', 'p4$$8899$$', '2017-10-17', '2018-10-17'),
(63, 14, 'Tempsens Asia', 'Triden', '', 'http://tempsens-asia.com', 'https://sg3plcpnl0082.prod.sin3.secureserver.net:2083/', 'tempsensasia123', 'eBLF$ZcGgPE2#E', '2016-01-27', '2021-01-27'),
(64, 11, 'Graha Indo Jaya', 'Andes', '', 'http://grahaindojaya.com/', 'https://grahaindojaya.com:2083/', 'grahain1', 'M2q3ncE0c2', '2017-08-07', '2018-08-07'),
(65, 11, 'Mamaqu', 'Wilson', '+6 819 828 518', 'http://bumbumamaqu.com', 'http://bumbumamaqu.com/cpanel', 'bumbumam', 'b5PBnz129o', '2018-04-30', '2019-04-29'),
(66, 12, 'Delimeat', 'Andriadi Winaga', '+62 811 903 557', 'http://delimeat.asia', 'http://delimeat.asia/cpanel', 'u2787688', 'E#2wj-NPcs', '2018-05-07', '2019-05-06'),
(67, 11, 'PT MT Tools Indonesia', 'Maria Felita', '081808847702', 'http://mateindo.co.id', 'http://mateindo.co.id/cpanel', 'mateindo', 'o7n[7mT3XKkQ:6', '2018-07-23', '2019-07-23'),
(68, 12, 'Delisa Group', 'Ryan Metamorphosys', '+62 877 7555 5190', 'http://delisa-group.com', 'http://delisa-group.com/cpanel', 'u4968506', '98kBFNj43ui{', '2018-05-30', '2019-05-30'),
(69, 0, 'Terasocial', 'Michael', '+62 878 8766 9424', 'http://terasocial.id', 'http://terasocial.id/cpanel', 'terasoci', 'Teradevelopment123!!', '2018-07-16', '2019-07-16'),
(70, 0, 'Surya Jalur Anugerah', 'Michael', '+62 878-8766-9424', 'http://suryajaluranugerah.com', 'http://suryajaluranugerah.com/cpanel', 'suryajal', 'Beon153SJA2019', '2015-02-02', '2019-02-02'),
(71, 0, 'Toto Klub', 'Jimmy', '+62 823-6808-9885', 'http://totoklub.com', 'http://totoklub.com/cpanel', 'totoklub', 'N]262mO2llPP-s', '2018-11-25', '2019-11-25'),
(72, 5, 'Diginusa', 'Triden Tan', '+62 878 6832 6233', 'http://diginusa.com', 'http://www.diginusa.com/plesk', 'k8933227', '73y8fDgb2T', '2019-01-25', '2020-01-25'),
(73, 11, 'Summer Time', 'Triden', '087868326233', 'http://summertime.id', 'http://summertime.id/cpanel', 'summerti', 'G45)j.EQrnK35l', '2019-02-12', '2020-02-12'),
(74, 17, 'Jessie Mike', 'Triden', '+62 878-6832-6233', 'http://jessiemike.com', 'http://jessiemike.com/cpanel', '(Login at Hostinger) --> jessiemikeshop@gmail.com', 'gmailjessiemike', '2018-12-26', '2019-12-26'),
(75, 11, 'Indo Sinar Jaya', 'Triden', '085668326233', 'http://indosinarjaya.com', 'indosinarjaya.com:2082', 'indosina', '1Dg698wWpd', '2015-06-11', '2020-06-11'),
(76, 12, 'Greyroos', 'Triden', '085668326233', 'http://greyroos.com', 'http://greyroos.com/cpanel', 'u5542883', '}CHTdD~75SPS', '2019-08-27', '2020-08-27'),
(77, 18, 'Universal Star Multilink', 'Tiyara', '+62 813-1893-0350', 'https://usm-alkesmata.com/', 'https://8011.dapurhosting.com:2083/', 'usmalkes', 'Alkesmatausm696844', '2020-03-12', '2021-03-12'),
(78, 7, 'Menara Cipta Label', 'Yenny', '0816 1986 548', 'http://menaraciptalabel.com', 'http://www.menaraciptalabel.com/cpanel', 'menaraci', 'UL]wu6V0;6r7Ki', '2020-07-30', '2021-07-30'),
(79, 0, 'Infigo', 'Sarah', '+62 857-1039-1297', 'https://infigo.id', 'https://infigo.id/cpanel', 'infigoko', 'antasari30', '2017-10-10', '2020-10-10');

-- --------------------------------------------------------

--
-- Table structure for table `domain_document`
--

DROP TABLE IF EXISTS `domain_document`;
CREATE TABLE `domain_document` (
  `id` int(5) NOT NULL,
  `client_id` int(5) NOT NULL,
  `name` varchar(120) NOT NULL,
  `file_name` varchar(220) NOT NULL,
  `last_update` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `domain_document`
--

INSERT INTO `domain_document` (`id`, `client_id`, `name`, `file_name`, `last_update`) VALUES
(1, 46, 'FTP Account', 'ftp account-54291302032017.pdf', '2017-03-02');

-- --------------------------------------------------------

--
-- Table structure for table `hosting_provider`
--

DROP TABLE IF EXISTS `hosting_provider`;
CREATE TABLE `hosting_provider` (
  `id` int(5) NOT NULL,
  `name` varchar(120) NOT NULL,
  `url` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hosting_provider`
--

INSERT INTO `hosting_provider` (`id`, `name`, `url`) VALUES
(4, 'Ardhosting', 'http://ardhosting.com'),
(5, 'Rumahweb', 'http://rumahweb.com'),
(6, 'Indonic', 'http://indonic.net'),
(7, 'Masterweb', 'http://masterweb.com'),
(8, 'Pasar Hosting', 'http://pasarhosting.com'),
(9, 'Webhostingpad', 'http://webhostingpad.com'),
(10, 'Hostgator', 'http://hostgator.com'),
(11, 'Qwords', 'https://www.qwords.com/'),
(12, 'Niagahoster', 'http://niagahoster.com'),
(13, 'Kilat Hosting', 'http://www.cloudkilat.com/'),
(14, 'Go Daddy', 'http://godaddy.com/'),
(15, 'Village Hoster', 'http://villagehoster.com'),
(16, 'Web Biz Asia', 'http://www.webbizasia.com/'),
(17, 'Hostinger', 'https://www.hostinger.co.id'),
(18, 'Dapur Hosting', 'https://dapurhosting.com'),
(19, 'Redo', 'warawda');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `privilege` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(200) NOT NULL,
  `is_active` varchar(5) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `pic_alt` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `privilege`, `name`, `username`, `password`, `phone`, `email`, `is_active`, `pic`, `pic_alt`) VALUES
(1, 1, 'Adi Chandra Halim', 'whitewater', '9d78bb0352be94373c25303c6152ea72', '(+62) 858 9081 2211', 'adi@dimbleweb.com', 'yes', 'whitewater-28480612082014.png', 'Whitewater'),
(7, 3, 'Admin', 'dimbleadmin', '5d99f064541388cee084b07889bf3f04', '', 'adihalim15@gmail.com', 'yes', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_privilege`
--

DROP TABLE IF EXISTS `user_privilege`;
CREATE TABLE `user_privilege` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `privilege` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_privilege`
--

INSERT INTO `user_privilege` (`id`, `name`, `privilege`) VALUES
(1, 'superadmin', '#all|'),
(3, 'Admin', '#conf|#user|#dom|');

-- --------------------------------------------------------

--
-- Table structure for table `web_config`
--

DROP TABLE IF EXISTS `web_config`;
CREATE TABLE `web_config` (
  `id` int(1) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `tag_line` varchar(220) NOT NULL,
  `address` varchar(220) NOT NULL,
  `building` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone1` varchar(30) NOT NULL,
  `phone2` varchar(30) NOT NULL,
  `email1` varchar(200) NOT NULL,
  `email2` varchar(200) NOT NULL,
  `twitter_link` varchar(500) NOT NULL,
  `facebook_link` varchar(500) NOT NULL,
  `youtube_link` varchar(500) NOT NULL,
  `blog_link` varchar(500) NOT NULL,
  `linkedin_link` varchar(500) NOT NULL,
  `pinterest_link` varchar(500) NOT NULL,
  `instagram_link` varchar(500) NOT NULL,
  `website_name` varchar(200) NOT NULL,
  `website_url` varchar(200) NOT NULL,
  `meta_copyright` varchar(200) NOT NULL,
  `meta_keywords` varchar(300) NOT NULL,
  `meta_description` varchar(200) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `logo_alt` varchar(200) NOT NULL,
  `favicon` varchar(200) NOT NULL,
  `dc_key` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `web_config`
--

INSERT INTO `web_config` (`id`, `company_name`, `tag_line`, `address`, `building`, `city`, `country`, `phone1`, `phone2`, `email1`, `email2`, `twitter_link`, `facebook_link`, `youtube_link`, `blog_link`, `linkedin_link`, `pinterest_link`, `instagram_link`, `website_name`, `website_url`, `meta_copyright`, `meta_keywords`, `meta_description`, `logo`, `logo_alt`, `favicon`, `dc_key`) VALUES
(1, 'Dimblestration', '', '', '', '', '', '(+62) 858 9081 2211', '', 'adi@dimbleweb.com', 'admin@dimbleweb.com', '', '', '', '', '', '', '', 'Dimblestration', 'http://dimblestration.dimbleweb.com', '', '', '', 'dimbleweb-logo-09330612082014.png', 'Dimbleweb Logo', 'dimblestration-favicon-59360612082014.png', 'd2f138c8f0eb9f15dc6523adaac8139d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_list`
--
ALTER TABLE `account_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_domain`
--
ALTER TABLE `client_domain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `domain_document`
--
ALTER TABLE `domain_document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hosting_provider`
--
ALTER TABLE `hosting_provider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_privilege`
--
ALTER TABLE `user_privilege`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `web_config`
--
ALTER TABLE `web_config`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_list`
--
ALTER TABLE `account_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_domain`
--
ALTER TABLE `client_domain`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `domain_document`
--
ALTER TABLE `domain_document`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hosting_provider`
--
ALTER TABLE `hosting_provider`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_privilege`
--
ALTER TABLE `user_privilege`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `web_config`
--
ALTER TABLE `web_config`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
